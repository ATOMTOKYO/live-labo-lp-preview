<?php /* Live-Labo new homepage (child theme front-page). Generated from LP. */ ?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="format-detection" content="telephone=no">
<title>ライバーデビュー応援キャンペーン｜Live-Labo（ライブラボ）</title>
<meta name="description" content="Pococha 歴代1位ライバー多数在籍。Live-Laboは還元率100%・住所提供・確定申告サポートまで完備のライバーマネジメント事務所。LINEから3分で無料相談。">
<meta property="og:title" content="ライバーデビュー応援キャンペーン｜Live-Labo">
<meta property="og:description" content="Pococha 歴代1位多数。あなたの"好き"を、武器にする。">
<meta property="og:image" content="https://live-labo.jp/wp/wp-content/themes/livelabonew/images/logo.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&family=Inter:wght@500;700;900&display=swap" rel="stylesheet">
<style>
  :root{
    --red:#d4002a;
    --red-deep:#a40020;
    --red-soft:#ffeef0;
    --black:#0e0e10;
    --gray-900:#1f1f23;
    --gray-700:#4a4a52;
    --gray-500:#8a8a92;
    --gray-300:#d8d8de;
    --gray-100:#f4f4f6;
    --cream:#fafafa;
    --line:#06c755;
    --line-deep:#04a847;
    --gold:#c8a456;
    /* ONECARAT風アクセント */
    --cyan:#10b5c9;
    --cyan-deep:#0d97a8;
    --cyan-soft:#e6f6f9;
    --yellow:#f4d63a;
    --shadow-sm:0 1px 2px rgba(14,14,16,.06),0 2px 8px rgba(14,14,16,.04);
    --shadow-md:0 4px 12px rgba(14,14,16,.08),0 12px 32px rgba(14,14,16,.06);
    --shadow-lg:0 8px 24px rgba(14,14,16,.12),0 24px 64px rgba(14,14,16,.08);
    --r-sm:8px; --r-md:14px; --r-lg:24px; --r-pill:999px;
    --ease:cubic-bezier(.22,.61,.36,1);
    --container:1200px;
  }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
  body{
    font-family:"Noto Sans JP","Hiragino Kaku Gothic ProN","Hiragino Sans",sans-serif;
    color:var(--gray-900);
    background:#fff;
    line-height:1.7;
    letter-spacing:.012em;
    font-feature-settings:"palt";
    line-break:strict;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    text-rendering:optimizeLegibility;
    padding-bottom:64px; /* 常時LINEバー分の余白 */
  }
  a{color:inherit;text-decoration:none}
  img{max-width:100%;height:auto;display:block}
  button{font-family:inherit;cursor:pointer;border:none;background:none}
  /* ---------- 大手感: 日本語組版の精緻化（改行の均等化・禁則・数字の等幅化） ---------- */
  h1,h2,h3,h4{text-wrap:balance;line-break:strict}
  p,li,dd,figcaption,blockquote{text-wrap:pretty}
  .stat-num,.metric-value,.num-value,.hero-metric-value,.cmp-table,
  .campaign-card-bonus,.liver-rank{font-variant-numeric:tabular-nums}

  /* ---------- Header ---------- */
  .site-header{
    position:sticky;top:0;z-index:50;
    background:rgba(255,255,255,.92);
    backdrop-filter:saturate(180%) blur(12px);
    -webkit-backdrop-filter:saturate(180%) blur(12px);
    border-bottom:1px solid var(--gray-100);
  }
  .header-inner{
    max-width:var(--container);margin:0 auto;
    padding:14px 24px;
    display:flex;align-items:center;justify-content:space-between;gap:24px;
  }
  .logo{display:flex;align-items:center;gap:10px;font-weight:900;color:var(--red);font-size:22px;letter-spacing:.02em}
  .logo img{height:32px;width:auto}
  .header-nav{display:flex;gap:28px;align-items:center}
  .header-nav a{font-size:14px;font-weight:500;color:var(--gray-700);transition:color .2s var(--ease)}
  .header-nav a:hover{color:var(--red)}
  .header-cta{
    display:inline-flex;align-items:center;gap:8px;
    padding:10px 18px;border-radius:var(--r-pill);
    background:var(--line);color:#fff;font-weight:700;font-size:14px;
    box-shadow:0 2px 0 #04a847,0 6px 16px rgba(6,199,85,.35);
    transition:transform .15s var(--ease),box-shadow .15s var(--ease);
  }
  .header-cta:hover{transform:translateY(-1px);box-shadow:0 3px 0 #04a847,0 10px 22px rgba(6,199,85,.4)}
  .header-cta::before{content:"";width:18px;height:18px;background:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'><path d='M12 2C6.48 2 2 5.86 2 10.6c0 2.74 1.6 5.17 4.09 6.78-.18.6-.65 2.2-.75 2.54-.12.43.16.43.34.32.14-.09 2.27-1.54 3.19-2.16.9.13 1.83.2 2.78.2c5.52 0 10-3.86 10-8.6S17.52 2 12 2z'/></svg>") no-repeat center/contain;display:inline-block}
  .nav-toggle{display:none;width:40px;height:40px;border-radius:8px;background:var(--gray-100);align-items:center;justify-content:center}
  .nav-toggle span{display:block;width:18px;height:2px;background:var(--gray-900);position:relative}
  .nav-toggle span::before,.nav-toggle span::after{content:"";position:absolute;left:0;width:100%;height:2px;background:var(--gray-900)}
  .nav-toggle span::before{top:-6px}.nav-toggle span::after{top:6px}

  /* ---------- Hero (ONECARAT準拠・1画面fold完結) ---------- */
  .hero{
    position:relative;overflow:hidden;
    background:
      radial-gradient(900px 500px at 100% 0%, var(--cyan-soft) 0%, transparent 55%),
      radial-gradient(700px 400px at 0% 100%, #fff4f6 0%, transparent 60%),
      #fff;
    padding:28px 0 32px;
  }
  .hero-inner{
    max-width:var(--container);margin:0 auto;padding:0 24px;
    display:flex;flex-direction:column;gap:14px;
  }
  /* 上部: 見出しブロック */
  .hero-head{text-align:left;max-width:1080px}
  .hero-badge{
    display:inline-flex;align-items:center;gap:8px;
    padding:6px 13px;border-radius:var(--r-pill);
    background:#fff;border:1px solid var(--red);color:var(--red);
    font-size:11px;font-weight:700;letter-spacing:.06em;
    box-shadow:var(--shadow-sm);
  }
  .hero-badge::before{content:"●";font-size:7px;animation:pulse 1.6s var(--ease) infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
  .hero-lead{
    margin-top:10px;
    font-size:clamp(14px,1.6vw,20px);font-weight:900;color:var(--black);
    letter-spacing:.02em;line-height:1.4;
  }
  .hero h1{
    margin-top:2px;
    font-size:clamp(18px,2.1vw,28px);
    line-height:1.35;letter-spacing:.02em;font-weight:900;
    color:var(--black);
  }
  .hero h1 .accent{color:var(--red);position:relative;display:inline-block}
  .hero h1 .accent::after{
    content:"";position:absolute;left:0;right:0;bottom:-2px;height:5px;
    background:linear-gradient(90deg,var(--red),#ff6680);border-radius:5px;opacity:.25;
  }
  /* Live-Laboオリジナル 巨大英字メイン: LIVE YOUR LIGHT. */
  .hero-en-mega{
    margin-top:10px;
    font-family:Inter,sans-serif;font-weight:900;
    font-size:clamp(40px,6vw,84px);letter-spacing:-.01em;
    color:var(--black);line-height:.92;
    text-transform:uppercase;
  }
  .hero-en-mega .glow{
    background:linear-gradient(135deg,var(--red) 0%,#ff6680 60%,var(--cyan) 100%);
    -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;
  }
  .hero-sub{margin-top:14px;font-size:14px;color:var(--gray-700);max-width:540px;line-height:1.75}

  /* 中部: 左スマホ｜右メトリクスパネル */
  .hero-main{
    display:grid;grid-template-columns:1fr 1.15fr;gap:20px;align-items:center;
  }
  /* ONECARAT風 メトリクスパネル: 黒バッジ → サブ説明 → 巨大シアン数字 */
  .hero-metrics-panel{
    display:flex;flex-direction:column;gap:10px;align-items:flex-start;
  }
  .metric-card{
    width:100%;
    display:flex;flex-direction:column;align-items:flex-start;gap:3px;
  }
  .metric-label{
    display:inline-block;
    padding:6px 18px;border-radius:var(--r-pill);
    background:var(--black);color:#fff;
    font-size:13px;font-weight:900;letter-spacing:.04em;
    box-shadow:0 4px 12px rgba(0,0,0,.18);
  }
  .metric-sub{
    font-size:12px;font-weight:700;color:var(--gray-700);letter-spacing:.04em;
  }
  .metric-value{
    font-family:Inter,sans-serif;font-weight:900;
    color:var(--cyan);font-size:clamp(38px,4.6vw,62px);
    line-height:1;letter-spacing:-.03em;
    text-shadow:0 4px 12px rgba(16,181,201,.15);
  }
  .metric-value small{
    font-size:.38em;color:var(--cyan-deep);font-weight:900;margin-left:3px;letter-spacing:0;
  }

  /* 下部: 所属ライバー写真ストリップ (compact) */
  .hero-photo-strip{
    margin-top:2px;
    display:grid;grid-template-columns:repeat(5,1fr);gap:8px;
  }
  .hero-photo-strip a{
    position:relative;display:block;aspect-ratio:1/1;
    overflow:hidden;border-radius:var(--r-md);
    background:#f0f0f3;
    box-shadow:0 4px 12px rgba(0,0,0,.08);
    transition:transform .25s var(--ease),box-shadow .25s var(--ease);
  }
  .hero-photo-strip a:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(0,0,0,.16)}
  .hero-photo-strip img{
    width:100%;height:100%;object-fit:cover;
    transition:transform .45s var(--ease);
  }
  .hero-photo-strip a:hover img{transform:scale(1.08)}
  .hero-ctas{margin-top:30px;display:flex;gap:14px;flex-wrap:wrap}
  .btn{
    display:inline-flex;align-items:center;justify-content:center;gap:10px;
    padding:18px 28px;border-radius:var(--r-pill);
    font-weight:700;font-size:16px;letter-spacing:.02em;
    transition:transform .15s var(--ease),box-shadow .15s var(--ease),background .2s var(--ease);
  }
  .btn-primary{background:var(--line);color:#fff;box-shadow:0 3px 0 #04a847,0 12px 28px rgba(6,199,85,.35)}
  .btn-primary:hover{transform:translateY(-2px);box-shadow:0 4px 0 #04a847,0 16px 36px rgba(6,199,85,.4)}
  .btn-secondary{background:var(--black);color:#fff;box-shadow:0 3px 0 #000,0 12px 28px rgba(0,0,0,.2)}
  .btn-secondary:hover{transform:translateY(-2px);background:var(--gray-900)}
  .btn-ghost{background:transparent;color:var(--gray-900);border:1.5px solid var(--gray-300)}
  .btn-ghost:hover{border-color:var(--black);background:var(--gray-100)}
  .btn-large{padding:22px 42px;font-size:18px}
  .btn-arrow::after{content:"→";font-weight:900;transition:transform .2s var(--ease)}
  .btn-arrow:hover::after{transform:translateX(4px)}

  .hero-trust{margin-top:28px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
  .hero-trust-avatars{display:flex}
  .hero-trust-avatars img{width:36px;height:36px;border-radius:50%;border:2px solid #fff;margin-left:-10px;object-fit:cover;box-shadow:var(--shadow-sm)}
  .hero-trust-avatars img:first-child{margin-left:0}
  .hero-trust-text{font-size:13px;color:var(--gray-700)}
  .hero-trust-text strong{color:var(--black);font-weight:900}

  /* ============ Hero phone mockup (ONECARAT風 配信画面) ============ */
  .hero-visual{position:relative;height:auto;display:flex;justify-content:center;align-items:center;min-height:auto}
  .phone-stage{position:relative;width:100%;display:flex;justify-content:center;align-items:center}
  .phone{
    position:relative;
    width:min(210px,82%);
    aspect-ratio:9/19.5;
    background:linear-gradient(180deg,#1c1c1e 0%,#0d0d0e 100%);
    border-radius:34px;
    padding:8px;
    box-shadow:
      0 22px 60px rgba(0,0,0,.26),
      0 10px 22px rgba(0,0,0,.16),
      inset 0 0 0 2px #2a2a2c;
  }
  .phone-notch{
    position:absolute;top:20px;left:50%;transform:translateX(-50%);
    width:110px;height:30px;background:#000;
    border-radius:18px;z-index:10;
  }
  .phone-screen{
    position:relative;width:100%;height:100%;
    border-radius:36px;overflow:hidden;background:#000;
  }
  .phone-bg{
    position:absolute;inset:0;
    width:100%;height:100%;object-fit:cover;
  }
  .phone-screen::after{
    /* 画面に微かな暗グラデを重ねてUI要素を読みやすく */
    content:"";position:absolute;inset:0;
    background:linear-gradient(180deg,rgba(0,0,0,.35) 0%,transparent 22%,transparent 70%,rgba(0,0,0,.6) 100%);
    pointer-events:none;z-index:2;
  }
  .live-top{
    position:absolute;top:62px;left:14px;right:14px;
    display:flex;justify-content:space-between;align-items:center;z-index:3;
  }
  .live-badge{
    background:linear-gradient(135deg,#ff2d4f 0%,#ff5a4a 100%);
    color:#fff;padding:5px 11px 5px 22px;border-radius:4px;
    font-family:Inter,sans-serif;font-size:11px;font-weight:900;letter-spacing:.06em;
    position:relative;
    box-shadow:0 4px 14px rgba(255,45,79,.45);
  }
  .live-badge::before{
    content:"";position:absolute;left:8px;top:50%;transform:translateY(-50%);
    width:8px;height:8px;border-radius:50%;background:#fff;
    animation:live-blink 1.2s ease-in-out infinite;
  }
  @keyframes live-blink{
    0%,100%{opacity:1}50%{opacity:.3}
  }
  .live-count{
    background:rgba(0,0,0,.5);backdrop-filter:blur(8px);
    -webkit-backdrop-filter:blur(8px);
    color:#fff;padding:5px 10px;border-radius:14px;
    font-family:Inter,sans-serif;font-size:10px;font-weight:700;letter-spacing:.04em;
    display:inline-flex;align-items:center;gap:5px;
  }
  .live-count::before{
    content:"";width:10px;height:10px;
    background:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'><path d='M12 4.5C7 4.5 2.7 7.6 1 12c1.7 4.4 6 7.5 11 7.5s9.3-3.1 11-7.5C21.3 7.6 17 4.5 12 4.5zm0 12.5a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z'/></svg>") no-repeat center/contain;
    display:inline-block;
  }
  .live-side{
    position:absolute;top:108px;right:14px;
    display:flex;flex-direction:column;gap:6px;z-index:3;align-items:center;
  }
  .viewer{
    width:32px;height:32px;border-radius:50%;
    border:2px solid #fff;object-fit:cover;
    box-shadow:0 3px 10px rgba(0,0,0,.3);
  }
  .viewer-more{
    margin-top:2px;font-family:Inter,sans-serif;font-size:9px;font-weight:800;
    color:#fff;background:rgba(0,0,0,.55);backdrop-filter:blur(8px);
    padding:3px 7px;border-radius:10px;letter-spacing:.04em;
  }
  .hearts-stream{
    position:absolute;bottom:120px;right:14px;
    width:70px;height:200px;pointer-events:none;z-index:3;
  }
  .heart{
    position:absolute;bottom:0;
    font-size:22px;color:#ff4d6d;line-height:1;
    text-shadow:0 2px 10px rgba(255,77,109,.5);
    animation:heart-rise 3.2s linear infinite;opacity:0;
  }
  .heart.h1{left:24px;animation-delay:0s}
  .heart.h2{left:6px;animation-delay:.7s;color:#ff8aa3;font-size:18px}
  .heart.h3{left:36px;animation-delay:1.4s;font-size:26px}
  .heart.h4{left:14px;animation-delay:2.1s;color:#ff6088}
  .heart.h5{left:42px;animation-delay:2.8s;font-size:20px}
  @keyframes heart-rise{
    0%{transform:translate(0,0) scale(.4);opacity:0}
    10%{opacity:1;transform:translate(0,-20px) scale(1)}
    40%{transform:translate(-8px,-80px) scale(1.1)}
    60%{transform:translate(6px,-120px) scale(1)}
    80%{opacity:.9;transform:translate(-4px,-160px) scale(1.1)}
    100%{transform:translate(0,-200px) scale(.7);opacity:0}
  }
  .live-bottom{
    position:absolute;bottom:18px;left:14px;right:14px;
    display:flex;flex-direction:column;gap:6px;z-index:3;align-items:flex-start;
  }
  .comment{
    background:rgba(0,0,0,.55);backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    color:#fff;padding:6px 12px;border-radius:14px;
    font-size:10px;font-weight:500;letter-spacing:.02em;
    max-width:75%;line-height:1.4;
    animation:comment-in .8s var(--ease) backwards;
  }
  .comment:nth-child(1){animation-delay:.5s}
  .comment:nth-child(2){animation-delay:1.5s}
  @keyframes comment-in{
    from{opacity:0;transform:translateY(10px)}
    to{opacity:1;transform:none}
  }
  .gift-bubble{
    background:linear-gradient(135deg,#ffd54a 0%,#ff8800 100%);
    color:#fff;padding:6px 14px;border-radius:14px;
    font-family:Inter,sans-serif;font-size:10px;font-weight:900;letter-spacing:.06em;
    box-shadow:0 6px 18px rgba(255,136,0,.4);
    animation:gift-pop 2.4s ease-in-out infinite;
  }
  @keyframes gift-pop{
    0%,100%{transform:scale(1)}50%{transform:scale(1.06)}
  }

  /* 浮遊バッジ（端末の外） */
  .badge-floor{
    position:absolute;
    font-weight:900;font-size:12px;
    padding:9px 16px;border-radius:var(--r-pill);
    z-index:5;letter-spacing:.04em;
    box-shadow:0 10px 24px rgba(0,0,0,.18);
    backdrop-filter:blur(8px);
    -webkit-backdrop-filter:blur(8px);
  }
  .floor-1{
    top:8%;right:6%;
    background:var(--red);color:#fff;
    transform:rotate(-4deg);
    box-shadow:0 12px 28px rgba(212,0,42,.35);
  }
  .floor-2{
    top:46%;left:0;
    background:#fff;color:var(--black);
    border:1px solid var(--gray-300);
    transform:rotate(3deg);
  }
  .floor-3{
    bottom:8%;right:0;
    background:var(--cyan);color:#fff;
    transform:rotate(-2deg);
    box-shadow:0 12px 28px rgba(16,181,201,.35);
  }

  /* ---------- Stats (ONECARAT風 白背景・シアン数字) ---------- */
  .stats{
    background:linear-gradient(180deg,#fff 0%,var(--cyan-soft) 100%);
    color:var(--black);padding:64px 24px;
    border-top:1px solid var(--gray-100);
    border-bottom:1px solid var(--gray-100);
  }
  .stats-inner{max-width:var(--container);margin:0 auto;display:grid;grid-template-columns:repeat(4,1fr);gap:32px}
  .stat{text-align:center;position:relative}
  .stat:not(:first-child)::before{
    content:"";position:absolute;left:0;top:18%;bottom:18%;width:1px;
    background:var(--gray-300);
  }
  .stat-num{
    font-family:Inter,sans-serif;font-weight:900;letter-spacing:-.03em;
    font-size:clamp(40px,5vw,64px);line-height:1;
    color:var(--cyan);
  }
  .stat-num small{
    font-size:.42em;font-weight:700;margin-left:4px;color:var(--cyan-deep);
  }
  .stat-label{
    margin-top:12px;font-size:12px;color:var(--gray-700);letter-spacing:.12em;
    font-weight:700;
  }

  /* ---------- Section common ---------- */
  section{padding:96px 24px}
  .section-inner{max-width:var(--container);margin:0 auto}
  .section-eyebrow{
    display:inline-block;color:var(--red);font-weight:700;font-size:13px;
    letter-spacing:.18em;text-transform:uppercase;
  }
  .section-title{
    margin-top:10px;font-size:clamp(28px,3.4vw,42px);
    line-height:1.3;font-weight:900;letter-spacing:-.005em;color:var(--black);
  }
  .section-title .accent{color:var(--red)}
  .nb{white-space:nowrap}
  .section-lead{margin-top:14px;color:var(--gray-700);font-size:16px;max-width:680px}

  /* ---------- Why (Reasons) ---------- */
  .reasons{background:var(--cream)}
  .reasons-grid{
    margin-top:48px;display:grid;grid-template-columns:repeat(3,1fr);gap:24px;
  }
  .reason{
    background:#fff;border-radius:var(--r-lg);padding:36px 28px;
    box-shadow:var(--shadow-sm);transition:transform .2s var(--ease),box-shadow .2s var(--ease);
    position:relative;overflow:hidden;
  }
  .reason::before{
    content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--red);
    transform:scaleY(0);transform-origin:top;transition:transform .3s var(--ease);
  }
  .reason:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}
  .reason:hover::before{transform:scaleY(1)}
  .reason-num{
    font-family:Inter,sans-serif;font-weight:900;color:var(--red);
    font-size:14px;letter-spacing:.1em;
  }
  .reason-icon{
    width:56px;height:56px;border-radius:14px;background:var(--red-soft);
    display:flex;align-items:center;justify-content:center;
    color:var(--red);margin-top:12px;
  }
  .reason-icon svg{width:28px;height:28px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
  .reason h3{margin-top:18px;font-size:20px;font-weight:900;color:var(--black);line-height:1.4}
  .reason p{margin-top:10px;font-size:14px;color:var(--gray-700);line-height:1.8}

  /* ---------- Liver Marquee (横スクロール) ---------- */
  .liver-marquee{
    position:relative;
    background:linear-gradient(180deg,#0e0e10 0%,#1a1a1d 100%);
    padding:0;overflow:hidden;
    border-top:3px solid var(--red);
  }
  .marquee-viewport{
    overflow:hidden;width:100%;
    /* 端をぼかすマスクで「永遠に流れている」感を演出 */
    -webkit-mask-image:linear-gradient(90deg,transparent 0%,#000 4%,#000 96%,transparent 100%);
    mask-image:linear-gradient(90deg,transparent 0%,#000 4%,#000 96%,transparent 100%);
  }
  .marquee-track{
    display:flex;width:max-content;gap:0;
    animation:m-scroll 55s linear infinite;
    will-change:transform;
  }
  .marquee-track:hover{animation-play-state:paused}
  @keyframes m-scroll{
    from{transform:translateX(0)}
    to{transform:translateX(-50%)}
  }
  .m-item{
    flex-shrink:0;display:block;
    width:clamp(120px,12vw,180px);
    aspect-ratio:1/1;
    position:relative;overflow:hidden;
    background:#000;
    transition:transform .3s var(--ease);
  }
  .m-item img{
    width:100%;height:100%;object-fit:cover;display:block;
    transition:transform .5s var(--ease),filter .3s var(--ease);
  }
  .m-item::after{
    content:"";position:absolute;inset:0;
    background:linear-gradient(180deg,transparent 60%,rgba(0,0,0,.35) 100%);
    pointer-events:none;opacity:.6;transition:opacity .3s var(--ease);
  }
  .m-item:hover{z-index:2}
  .m-item:hover img{transform:scale(1.12);filter:saturate(1.1)}
  .m-item:hover::after{opacity:0}
  .marquee-caption{
    position:absolute;left:50%;bottom:14px;transform:translateX(-50%);
    z-index:3;padding:8px 18px;border-radius:var(--r-pill);
    background:rgba(0,0,0,.65);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
    color:#fff;font-size:12px;font-weight:700;letter-spacing:.03em;
    border:1px solid rgba(255,255,255,.12);
    box-shadow:0 4px 16px rgba(0,0,0,.4);
    white-space:nowrap;
    pointer-events:none;
  }
  /* アクセシビリティ: ユーザーが動きを減らす設定を有効にしている場合は停止 */
  @media (prefers-reduced-motion: reduce){
    .marquee-track{animation:none}
    .marquee-viewport{overflow-x:auto}
  }

  /* ---------- Activity Tags (ONECARAT風カテゴリ行) ---------- */
  .activity-tags{padding:36px 24px;background:#fff;border-bottom:1px solid var(--gray-100)}
  .activity-tags .section-inner{display:flex;justify-content:center}
  .atag-list{
    list-style:none;display:flex;flex-wrap:wrap;justify-content:center;
    gap:8px 32px;
  }
  .atag-list li{
    font-family:Inter,sans-serif;font-weight:900;font-size:18px;
    letter-spacing:.18em;color:var(--gray-300);
    transition:color .25s var(--ease);
    position:relative;
  }
  .atag-list li:hover{color:var(--black)}
  .atag-list li:not(:last-child)::after{
    content:"";display:inline-block;width:6px;height:6px;border-radius:50%;
    background:var(--cyan);margin-left:32px;vertical-align:middle;
    margin-bottom:3px;
  }

  /* ---------- Media Strip ---------- */
  .media-strip{background:#fff;padding:32px 24px;border-top:1px solid var(--gray-100);border-bottom:1px solid var(--gray-100)}
  .media-eyebrow{
    text-align:center;color:var(--gray-500);font-size:11px;letter-spacing:.2em;font-weight:700;
  }
  .media-logos{
    margin-top:18px;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;
    gap:14px 28px;
  }
  .ml{
    font-family:Inter,"Noto Sans JP",sans-serif;
    color:var(--gray-500);font-weight:700;font-size:14px;letter-spacing:.04em;
    padding:6px 16px;border:1px solid var(--gray-300);border-radius:6px;
    transition:color .2s var(--ease),border-color .2s var(--ease);
  }
  .ml:hover{color:var(--gray-900);border-color:var(--gray-700)}

  /* ---------- Other Support (9 icons) ---------- */
  .other-support{background:var(--cream)}
  .os-heading{max-width:760px}
  .os-grid{
    margin-top:48px;display:grid;grid-template-columns:repeat(3,1fr);gap:20px;
  }
  .os-item{
    background:#fff;border-radius:var(--r-md);padding:24px 20px;
    display:flex;align-items:center;gap:18px;
    box-shadow:var(--shadow-sm);
    transition:transform .2s var(--ease),box-shadow .2s var(--ease);
  }
  .os-item:hover{transform:translateY(-3px);box-shadow:var(--shadow-md)}
  .os-icon{
    width:64px;height:64px;flex-shrink:0;border-radius:50%;
    background:var(--red-soft);
    display:flex;align-items:center;justify-content:center;
    color:var(--red);
    box-shadow:inset 0 0 0 1px rgba(212,0,42,.08);
  }
  .os-icon svg{width:32px;height:32px}
  .os-label{font-size:15px;font-weight:900;color:var(--black);line-height:1.4}

  /* ---------- What You Get ---------- */
  .what-you-get{background:#fff}
  .wyg-wrap{
    display:grid;grid-template-columns:1fr 1.2fr;gap:64px;align-items:start;
    padding:32px 0;
  }
  .wyg-list{list-style:none;display:grid;gap:20px}
  .wyg-list li{
    display:grid;grid-template-columns:60px 1fr;gap:20px;align-items:start;
    padding:24px 24px 24px 0;border-bottom:1px solid var(--gray-100);
  }
  .wyg-list li:last-child{border-bottom:none}
  .wyg-num{
    font-family:Inter,sans-serif;font-weight:900;font-size:32px;
    color:var(--red);line-height:1;letter-spacing:-.02em;
  }
  .wyg-list h3{font-size:19px;font-weight:900;color:var(--black);line-height:1.4}
  .wyg-list p{margin-top:6px;font-size:14px;color:var(--gray-700);line-height:1.8}

  /* ---------- Recommendation (editorial-style refined) ---------- */
  .recommendation{background:linear-gradient(180deg,#fff 0%,var(--cream) 100%)}
  .reco-grid{
    margin-top:56px;display:grid;grid-template-columns:repeat(3,1fr);gap:18px;
  }
  .reco-card{
    background:#fff;border-radius:18px;padding:36px 28px 32px;
    box-shadow:0 1px 0 var(--gray-100),0 12px 32px rgba(14,14,16,.04);
    position:relative;overflow:hidden;
    border:1px solid rgba(14,14,16,.06);
    transition:transform .3s var(--ease),box-shadow .3s var(--ease),border-color .3s var(--ease);
  }
  .reco-card::before{
    content:"";position:absolute;left:0;top:0;height:3px;width:100%;
    background:linear-gradient(90deg,var(--red) 0%,var(--cyan) 100%);
    opacity:.85;
  }
  .reco-card:hover{
    transform:translateY(-6px);
    box-shadow:0 1px 0 var(--gray-100),0 24px 56px rgba(14,14,16,.10);
    border-color:rgba(212,0,42,.18);
  }
  .reco-icon{
    width:60px;height:60px;border-radius:50%;
    background:var(--red-soft);
    display:flex;align-items:center;justify-content:center;
    color:var(--red);
    box-shadow:inset 0 0 0 1px rgba(212,0,42,.08);
  }
  .reco-icon svg{width:28px;height:28px}
  .reco-card h3{margin-top:22px;font-size:18px;font-weight:900;color:var(--black);line-height:1.45;letter-spacing:.01em}
  .reco-card p{margin-top:12px;font-size:13.5px;color:var(--gray-700);line-height:1.95;letter-spacing:.02em}

  /* ---------- Comparison Table (editorial / hairline borders) ---------- */
  .comparison{background:#fff}
  .cmp-table-wrap{margin-top:56px;overflow-x:auto;border-radius:16px;border:1px solid rgba(14,14,16,.08);box-shadow:0 24px 60px rgba(14,14,16,.04)}
  .cmp-table{
    width:100%;border-collapse:collapse;
    font-size:14px;background:#fff;
    font-variant-numeric:tabular-nums;
  }
  .cmp-table th,.cmp-table td{
    padding:20px 18px;text-align:center;border-bottom:1px solid rgba(14,14,16,.06);
    letter-spacing:.02em;
  }
  .cmp-table tbody tr:last-child th,.cmp-table tbody tr:last-child td{border-bottom:none}
  .cmp-table thead th{
    background:#fafafb;font-weight:700;font-size:12px;color:var(--gray-700);
    letter-spacing:.12em;text-transform:uppercase;padding:18px 14px;
  }
  .cmp-table thead th.us{
    background:linear-gradient(135deg,var(--red) 0%,var(--red-deep) 100%);color:#fff;
    font-size:14px;letter-spacing:.06em;text-transform:none;
    position:relative;
  }
  .cmp-table thead th.us::after{
    content:"";position:absolute;left:0;right:0;bottom:-1px;height:3px;
    background:var(--red);
  }
  .cmp-table tbody th{
    text-align:left;font-weight:700;color:var(--gray-900);background:#fafafb;
    width:220px;font-size:14px;letter-spacing:.03em;
  }
  .cmp-table tbody td{color:var(--gray-700);font-weight:500}
  .cmp-table tbody tr:hover td{background:rgba(212,0,42,.015)}
  .cmp-table td.us{
    background:linear-gradient(180deg,#fff7f9 0%,#fff 100%);
    color:var(--red);font-weight:900;font-size:15px;
    border-left:1px solid rgba(212,0,42,.18);border-right:1px solid rgba(212,0,42,.18);
    position:relative;
  }
  .cmp-table td.us strong{font-size:20px;letter-spacing:-.01em}
  .cmp-table tbody tr:last-child td.us{
    border-bottom:none;
    box-shadow:inset 0 -3px 0 var(--red);
  }
  .cmp-note{margin-top:18px;font-size:11px;color:var(--gray-500);text-align:right;letter-spacing:.04em}

  /* ---------- Voice (magazine-style testimonials) ---------- */
  .voice{background:linear-gradient(180deg,var(--cream) 0%,#fff 100%)}
  .voice-grid{
    margin-top:56px;display:grid;grid-template-columns:repeat(3,1fr);gap:22px;
  }
  .voice-card{
    background:#fff;border-radius:18px;padding:36px 30px 32px;
    box-shadow:0 1px 0 var(--gray-100),0 16px 36px rgba(14,14,16,.05);
    position:relative;overflow:hidden;
    border:1px solid rgba(14,14,16,.06);
    transition:transform .3s var(--ease),box-shadow .3s var(--ease);
  }
  .voice-card:hover{
    transform:translateY(-4px);
    box-shadow:0 1px 0 var(--gray-100),0 28px 56px rgba(14,14,16,.08);
  }
  .voice-card::before{
    content:"\201C";position:absolute;top:-12px;left:18px;
    font-family:Georgia,"Times New Roman",serif;font-size:110px;line-height:1;
    color:var(--red);opacity:.10;font-weight:900;
  }
  .voice-quote{
    font-size:17px;font-weight:900;color:var(--black);line-height:1.6;
    padding-top:14px;letter-spacing:.02em;position:relative;
  }
  .voice-meta{
    margin-top:24px;padding-top:20px;display:flex;align-items:center;gap:14px;
    border-top:1px solid rgba(14,14,16,.06);
  }
  .voice-meta img{
    width:50px;height:50px;border-radius:50%;object-fit:cover;
    border:2px solid #fff;box-shadow:0 4px 12px rgba(14,14,16,.10);
  }
  .voice-avatar{
    width:50px;height:50px;border-radius:50%;flex:none;
    display:flex;align-items:center;justify-content:center;
    background:var(--red-soft);color:var(--red);
    font-weight:900;font-size:14px;letter-spacing:.04em;
    border:2px solid #fff;box-shadow:0 4px 12px rgba(14,14,16,.10);
  }
  .voice-meta strong{display:block;font-size:14px;color:var(--black);font-weight:900;letter-spacing:.02em}
  .voice-meta span{display:block;font-size:11px;color:var(--gray-500);margin-top:3px;letter-spacing:.06em;text-transform:uppercase}
  .voice-body{margin-top:18px;font-size:13px;color:var(--gray-700);line-height:1.95;letter-spacing:.02em}

  /* ---------- Platforms (PARTNER wall, ONECARAT-style) ---------- */
  .platforms{
    background:
      radial-gradient(800px 400px at 50% 0%, rgba(212,0,42,.15) 0%, transparent 60%),
      linear-gradient(180deg,#141416 0%,#0a0a0c 100%);
    color:#fff;
  }
  .platforms-head{text-align:center;max-width:680px;margin:0 auto}
  .platforms-title{
    font-family:Inter,sans-serif;font-weight:900;letter-spacing:.04em;
    font-size:clamp(40px,5.5vw,72px);line-height:1;
    background:linear-gradient(180deg,#fff 0%,#a9a9b1 110%);
    -webkit-background-clip:text;background-clip:text;color:transparent;
  }
  .platforms-sub{
    margin-top:12px;font-size:18px;font-weight:700;color:#fff;letter-spacing:.04em;
  }
  .platforms-lead{margin-top:14px;color:rgba(255,255,255,.65);font-size:15px;line-height:1.8}
  /* 全アプリアイコンを同一サイズ・正方形のフルブリード公式アイコンで統一 */
  .platform-icons{
    margin:56px auto 0;max-width:840px;
    display:grid;grid-template-columns:repeat(5,1fr);gap:30px 26px;
  }
  .picon{
    display:flex;flex-direction:column;align-items:center;gap:14px;
    text-decoration:none;color:#fff;position:relative;
    transition:transform .2s var(--ease);
  }
  .picon:hover{transform:translateY(-5px)}
  .picon-art{
    width:100%;aspect-ratio:1/1;border-radius:22%;
    overflow:hidden;position:relative;background:#fff;
    box-shadow:0 12px 30px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.08) inset;
    transition:box-shadow .25s var(--ease);
  }
  .picon:hover .picon-art{box-shadow:0 18px 44px rgba(0,0,0,.55),0 0 0 1px rgba(255,255,255,.14) inset}
  .picon-img{
    width:100%;height:100%;object-fit:cover;display:block;
  }
  .picon-name{font-size:13px;font-weight:700;letter-spacing:.02em;color:rgba(255,255,255,.92)}
  .picon[data-rank]::before{
    content:attr(data-rank);position:absolute;top:-8px;right:-8px;z-index:2;
    padding:5px 10px;border-radius:var(--r-pill);
    background:linear-gradient(135deg,#ffd54a 0%,#ffb800 100%);color:#3d2400;
    font-size:10px;font-weight:900;letter-spacing:.04em;white-space:nowrap;
    box-shadow:0 3px 10px rgba(255,184,0,.5);
  }
  .platforms-note{
    margin-top:48px;text-align:center;font-size:11px;color:rgba(255,255,255,.4);
  }

  /* ---------- Premium Opportunities ---------- */
  .premium-opps{
    background:linear-gradient(180deg,#fff 0%,var(--cyan-soft) 100%);
    padding:96px 24px;
  }
  .premium-opps .section-title{margin-bottom:14px}
  .opps-grid{
    margin-top:48px;
    display:grid;grid-template-columns:repeat(3,1fr);gap:20px;
    grid-auto-rows:auto;
  }
  .opp-card{
    background:#fff;border-radius:var(--r-lg);padding:32px 26px 28px;
    box-shadow:var(--shadow-sm);position:relative;
    transition:transform .25s var(--ease),box-shadow .25s var(--ease);
    overflow:hidden;
    display:flex;flex-direction:column;
  }
  .opp-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}
  /* フィーチャー1枚目（始球式）は2列分使う */
  .opp-feature{
    grid-column:span 2;
    padding:0;display:grid;grid-template-columns:1.1fr 1fr;align-items:stretch;
    background:#fff;
  }
  .opp-feature .opp-img{
    position:relative;min-height:260px;overflow:hidden;
    background:var(--gray-100);
  }
  .opp-feature .opp-img img{
    position:absolute;inset:0;width:100%;height:100%;
    object-fit:cover;object-position:center 42%;
    transition:transform .8s var(--ease);
  }
  .opp-feature:hover .opp-img img{transform:scale(1.04)}
  .opp-feature .opp-body{padding:36px 32px;display:flex;flex-direction:column;justify-content:center}
  .opp-feature h3{font-size:22px}
  .opp-feature p{margin-top:14px}
  .opp-icon{
    width:52px;height:52px;border-radius:14px;
    background:linear-gradient(135deg,var(--cyan-soft) 0%,#cfecf2 100%);
    display:flex;align-items:center;justify-content:center;
    color:var(--cyan-deep);margin-bottom:14px;
  }
  .opp-icon svg{width:28px;height:28px}
  .opp-tag{
    display:inline-block;
    font-family:Inter,sans-serif;font-size:10px;font-weight:900;
    letter-spacing:.18em;color:var(--cyan);
    padding:4px 10px;border:1px solid var(--cyan);border-radius:3px;
    margin-bottom:14px;
  }
  .opp-feature .opp-tag{align-self:flex-start}
  .opp-card h3{
    font-size:18px;font-weight:900;color:var(--black);line-height:1.5;
    letter-spacing:.02em;
  }
  .opp-card p{
    margin-top:12px;font-size:13px;color:var(--gray-700);line-height:1.85;
  }
  .opps-note{
    margin-top:24px;text-align:right;
    font-size:11px;color:var(--gray-500);
  }

  /* ---------- Livers (photo + name below, expandable) ---------- */
  .livers{background:var(--cream)}
  .livers-grid{
    margin-top:48px;display:grid;grid-template-columns:repeat(4,1fr);gap:28px 22px;
  }
  .liver-card{
    display:flex;flex-direction:column;
    transition:transform .25s var(--ease);
  }
  .liver-card.is-extra{display:none}
  .livers-grid.is-expanded .liver-card.is-extra{
    display:flex;animation:liver-reveal .55s var(--ease) both;
  }
  @keyframes liver-reveal{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
  .liver-photo{
    position:relative;border-radius:var(--r-md);overflow:hidden;aspect-ratio:3/4;
    background:var(--gray-100);
    box-shadow:0 1px 0 var(--gray-100),0 10px 26px rgba(14,14,16,.06);
  }
  .liver-photo::after{
    content:"";position:absolute;inset:0;border-radius:var(--r-md);
    box-shadow:inset 0 0 0 1px rgba(14,14,16,.05);pointer-events:none;
  }
  .liver-card img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s var(--ease)}
  .liver-card:hover .liver-photo{box-shadow:0 1px 0 var(--gray-100),0 18px 40px rgba(14,14,16,.12)}
  .liver-card:hover img{transform:scale(1.06)}
  .liver-name{
    margin-top:14px;text-align:center;
    font-weight:900;font-size:15px;color:var(--black);letter-spacing:.02em;line-height:1.4;
  }
  .liver-rookie-tag{
    align-self:center;margin-top:7px;
    padding:2px 11px;border-radius:var(--r-pill);
    background:var(--cyan-soft);color:var(--cyan-deep);
    font-family:Inter,sans-serif;font-size:9px;font-weight:900;letter-spacing:.16em;
  }
  /* さらに表示ボタン */
  .livers-more{text-align:center;margin-top:46px}
  .liver-more-btn{
    display:inline-flex;align-items:center;gap:14px;
    padding:16px 38px;border-radius:var(--r-pill);
    background:#fff;border:1.5px solid var(--gray-300);
    color:var(--gray-900);font-weight:900;font-size:15px;letter-spacing:.04em;
    cursor:pointer;
    box-shadow:0 6px 18px rgba(14,14,16,.05);
    transition:border-color .2s var(--ease),color .2s var(--ease),transform .2s var(--ease),box-shadow .2s var(--ease);
  }
  .liver-more-btn:hover{
    border-color:var(--red);color:var(--red);transform:translateY(-2px);
    box-shadow:0 12px 28px rgba(212,0,42,.12);
  }
  .liver-more-btn .lmb-icon{
    width:22px;height:22px;border-radius:50%;background:var(--red);flex-shrink:0;
    display:inline-flex;align-items:center;justify-content:center;
    transition:transform .35s var(--ease);
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none' stroke='white' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6l4 4 4-4'/></svg>");
    background-repeat:no-repeat;background-position:center;background-size:11px 11px;
  }
  .livers-grid.is-expanded ~ .livers-more .lmb-icon{transform:rotate(180deg)}

  /* ---------- Campaign Box ---------- */
  .campaign{background:linear-gradient(135deg,#0e0e10 0%,#2a0510 100%);color:#fff;padding:0}
  .campaign-inner{
    max-width:var(--container);margin:0 auto;padding:80px 24px;
    display:grid;grid-template-columns:1.2fr .8fr;gap:48px;align-items:center;
  }
  .campaign-eyebrow{
    display:inline-flex;align-items:center;gap:10px;
    padding:8px 16px;border-radius:var(--r-pill);
    background:var(--red);font-size:12px;font-weight:700;letter-spacing:.1em;
  }
  .campaign-eyebrow::before{content:"●";font-size:8px;animation:pulse 1.6s var(--ease) infinite}
  .campaign h2{
    margin-top:18px;font-size:clamp(28px,3.6vw,46px);
    line-height:1.25;font-weight:900;
  }
  .campaign h2 .hl{
    background:linear-gradient(90deg,var(--cyan) 0%,#5fd3e0 100%);
    -webkit-background-clip:text;background-clip:text;color:transparent;
    white-space:nowrap;
  }
  .campaign-list{margin-top:24px;display:grid;gap:12px}
  .campaign-list li{
    list-style:none;padding-left:32px;position:relative;font-size:15px;color:rgba(255,255,255,.85);
  }
  .campaign-list li::before{
    content:"✓";position:absolute;left:0;top:0;
    width:22px;height:22px;border-radius:50%;background:#fff;color:var(--red);
    display:flex;align-items:center;justify-content:center;font-weight:900;font-size:13px;
  }
  .campaign-card{
    background:#fff;color:var(--black);border-radius:var(--r-lg);
    padding:36px 32px;box-shadow:var(--shadow-lg);text-align:center;
  }
  .campaign-card-label{color:var(--red);font-weight:700;font-size:13px;letter-spacing:.1em}
  .campaign-card-period{margin-top:8px;font-size:14px;color:var(--gray-700)}
  .campaign-card-bonus{
    margin-top:16px;font-family:Inter,sans-serif;font-weight:900;
    font-size:48px;line-height:1;color:var(--black);
  }
  .campaign-card-bonus small{font-size:.4em;color:var(--gray-700)}
  .campaign-card-note{margin-top:8px;font-size:12px;color:var(--gray-500)}
  .campaign-card .btn{margin-top:20px;width:100%}

  /* ---------- Flow (editorial step indicators) ---------- */
  .flow{background:linear-gradient(180deg,var(--cream) 0%,#fff 100%)}
  .flow-grid{
    margin-top:56px;display:grid;grid-template-columns:repeat(4,1fr);gap:18px;
    position:relative;
  }
  .flow-step{
    background:#fff;border-radius:18px;padding:36px 28px 32px;
    box-shadow:0 1px 0 var(--gray-100),0 16px 36px rgba(14,14,16,.04);
    position:relative;
    border:1px solid rgba(14,14,16,.06);
    transition:transform .3s var(--ease),box-shadow .3s var(--ease);
  }
  .flow-step:hover{
    transform:translateY(-4px);
    box-shadow:0 1px 0 var(--gray-100),0 24px 56px rgba(14,14,16,.08);
  }
  .flow-step::before{
    content:"";position:absolute;left:28px;top:0;width:36px;height:3px;
    background:linear-gradient(90deg,var(--red) 0%,var(--cyan) 100%);
  }
  .flow-step-num{
    font-family:Inter,sans-serif;font-weight:900;color:var(--gray-300);
    font-size:56px;line-height:1;letter-spacing:-.04em;
    font-variant-numeric:tabular-nums;
  }
  .flow-step h3{margin-top:14px;font-size:18px;font-weight:900;color:var(--black);letter-spacing:.02em}
  .flow-step p{margin-top:10px;font-size:13.5px;color:var(--gray-700);line-height:1.9;letter-spacing:.02em}
  .flow-step:not(:last-child)::after{
    content:"";position:absolute;right:-12px;top:50%;transform:translateY(-50%);
    width:24px;height:24px;border-radius:50%;
    background:var(--red);
    z-index:2;
    box-shadow:0 4px 12px rgba(212,0,42,.32);
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 4l4 4-4 4'/></svg>");
    background-repeat:no-repeat;background-position:center;background-size:14px 14px;
  }

  /* ---------- FAQ (refined accordion) ---------- */
  .faq{background:#fff}
  .faq-list{margin-top:48px;display:grid;gap:10px;max-width:920px;margin-left:auto;margin-right:auto}
  .faq-item{
    border:1px solid rgba(14,14,16,.10);border-radius:14px;
    overflow:hidden;background:#fff;
    transition:border-color .25s var(--ease),box-shadow .25s var(--ease),background .25s var(--ease);
  }
  .faq-item:hover{border-color:rgba(212,0,42,.25);background:#fafafb}
  .faq-item[open]{
    border-color:rgba(212,0,42,.35);
    box-shadow:0 12px 32px rgba(14,14,16,.06);
    background:#fff;
  }
  .faq-item summary{
    list-style:none;cursor:pointer;padding:22px 26px;
    display:flex;align-items:center;gap:18px;
    font-weight:900;color:var(--black);font-size:15px;letter-spacing:.02em;
  }
  .faq-item summary::-webkit-details-marker{display:none}
  .faq-item summary::before{
    content:"Q";flex-shrink:0;width:34px;height:34px;border-radius:10px;
    background:linear-gradient(135deg,var(--red) 0%,var(--red-deep) 100%);color:#fff;
    display:flex;align-items:center;justify-content:center;
    font-family:Inter,sans-serif;font-weight:900;font-size:14px;letter-spacing:.04em;
    box-shadow:0 4px 12px rgba(212,0,42,.25);
  }
  .faq-item summary::after{
    content:"";margin-left:auto;flex-shrink:0;
    width:24px;height:24px;border-radius:50%;
    background:rgba(14,14,16,.06);
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none' stroke='%231a1a1a' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6l4 4 4-4'/></svg>");
    background-repeat:no-repeat;background-position:center;background-size:14px 14px;
    transition:transform .3s var(--ease),background .25s var(--ease);
  }
  .faq-item[open] summary::after{
    transform:rotate(180deg);
    background-color:rgba(212,0,42,.10);
  }
  .faq-item .faq-body{
    padding:4px 26px 24px 78px;color:var(--gray-700);
    font-size:14px;line-height:1.95;letter-spacing:.02em;
  }
  .faq-item[open] .faq-body{animation:faq-fade .35s var(--ease) both}
  @keyframes faq-fade{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}

  /* ---------- Quick Form (editorial corporate form) ---------- */
  .quick-form{background:linear-gradient(180deg,#fff 0%,var(--cream) 100%)}
  .qf-wrap{
    display:grid;grid-template-columns:1fr 1.05fr;gap:72px;align-items:start;
    background:#fff;border-radius:24px;padding:56px;
    box-shadow:0 1px 0 var(--gray-100),0 32px 80px rgba(14,14,16,.06);
    border:1px solid rgba(14,14,16,.05);
  }
  .qf-bullets{margin-top:28px;list-style:none;display:grid;gap:14px;padding-top:24px;border-top:1px solid rgba(14,14,16,.06)}
  .qf-bullets li{
    padding-left:32px;position:relative;font-size:14px;color:var(--gray-700);
    line-height:1.6;letter-spacing:.02em;
  }
  .qf-bullets li::before{
    content:"";position:absolute;left:0;top:1px;
    width:22px;height:22px;border-radius:50%;
    background:linear-gradient(135deg,var(--red) 0%,var(--red-deep) 100%);
    box-shadow:0 4px 10px rgba(212,0,42,.22);
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none' stroke='white' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'><path d='M3 8l3 3 7-7'/></svg>");
    background-repeat:no-repeat;background-position:center;background-size:12px 12px;
  }
  .qf-form{display:grid;gap:20px}
  .qf-row{display:grid;gap:8px}
  .qf-row label{
    font-size:12px;font-weight:900;color:var(--gray-700);
    display:flex;align-items:center;gap:10px;
    letter-spacing:.12em;text-transform:uppercase;
  }
  .req{
    display:inline-block;padding:2px 8px;border-radius:4px;
    background:var(--red);color:#fff;font-size:10px;font-weight:900;
    letter-spacing:.06em;
  }
  .qf-row input,.qf-row select{
    padding:16px 18px;border:1.5px solid rgba(14,14,16,.12);border-radius:12px;
    font-size:15px;font-family:inherit;background:#fff;color:var(--black);
    letter-spacing:.02em;
    transition:border-color .2s var(--ease),box-shadow .2s var(--ease),background .2s var(--ease);
  }
  .qf-row input:hover,.qf-row select:hover{border-color:rgba(14,14,16,.24)}
  .qf-row input:focus,.qf-row select:focus{
    outline:none;border-color:var(--red);
    box-shadow:0 0 0 4px rgba(212,0,42,.10);
    background:#fff;
  }
  .qf-row input::placeholder{color:var(--gray-500);font-weight:500}
  .qf-row select{
    appearance:none;-webkit-appearance:none;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='none' stroke='%234a4a52' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6l4 4 4-4'/></svg>");
    background-repeat:no-repeat;background-position:right 18px center;background-size:14px;
    padding-right:44px;
  }
  .qf-radio{display:flex;gap:8px;flex-wrap:wrap}
  .qf-radio label{
    display:flex;align-items:center;gap:8px;cursor:pointer;
    padding:10px 16px;border-radius:10px;
    background:#fafafb;border:1.5px solid rgba(14,14,16,.08);
    font-size:13px;font-weight:700;color:var(--gray-900);
    letter-spacing:.02em;text-transform:none;
    transition:all .2s var(--ease);
  }
  .qf-radio label:hover{border-color:rgba(212,0,42,.3);background:#fff}
  .qf-radio label:has(input:checked){
    background:linear-gradient(135deg,#fff5f7 0%,#fff 100%);
    border-color:var(--red);color:var(--red);
  }
  .qf-radio input{accent-color:var(--red);width:14px;height:14px}
  .qf-note{font-size:11px;color:var(--gray-500);text-align:center;margin-top:12px;letter-spacing:.04em;line-height:1.7}
  .qf-note a{color:var(--gray-700);text-decoration:underline;text-underline-offset:2px}

  /* ---------- Bottom CTA (refined) ---------- */
  .cta-final{
    position:relative;overflow:hidden;
    background:
      radial-gradient(900px 400px at 20% 0%, rgba(212,0,42,.20) 0%, transparent 60%),
      radial-gradient(700px 300px at 90% 100%, rgba(16,181,201,.10) 0%, transparent 60%),
      linear-gradient(180deg,#121214 0%,#08080a 100%);
    color:#fff;text-align:center;
  }
  .cta-final::before{
    content:"";position:absolute;left:50%;top:0;width:120px;height:1px;
    background:linear-gradient(90deg,transparent 0%,var(--red) 50%,transparent 100%);
    transform:translateX(-50%);
  }
  .cta-final h2{
    font-size:clamp(28px,3.6vw,48px);font-weight:900;line-height:1.3;
    letter-spacing:.02em;
  }
  .cta-final p{margin-top:20px;color:rgba(255,255,255,.72);font-size:15.5px;line-height:1.8;letter-spacing:.02em}
  .cta-final-buttons{margin-top:40px;display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
  .cta-final-buttons .btn-ghost{color:#fff;border-color:rgba(255,255,255,.28)}
  .cta-final-buttons .btn-ghost:hover{border-color:#fff;background:rgba(255,255,255,.08)}
  .cta-final-note{margin-top:24px;font-size:11px;color:rgba(255,255,255,.42);letter-spacing:.06em}
  .cta-final-urgency{
    margin-top:20px;display:inline-flex;align-items:center;gap:10px;
    padding:9px 20px;border-radius:var(--r-pill);
    background:rgba(212,0,42,.14);color:#ff6884;font-size:12.5px;font-weight:700;
    letter-spacing:.08em;border:1px solid rgba(212,0,42,.36);
    text-transform:uppercase;
  }
  .cta-final-urgency::before{
    content:"";width:6px;height:6px;border-radius:50%;background:#ff6884;
    animation:pulse 1.6s var(--ease) infinite;box-shadow:0 0 8px rgba(255,104,132,.55);
  }

  /* ---------- Footer (refined corporate) ---------- */
  .site-footer{
    background:#08080a;color:rgba(255,255,255,.55);padding:64px 24px 40px;font-size:13px;
    border-top:1px solid rgba(255,255,255,.05);
  }
  .footer-inner{
    max-width:var(--container);margin:0 auto;
    display:flex;justify-content:space-between;align-items:center;gap:24px;flex-wrap:wrap;
    padding-top:24px;border-top:1px solid rgba(255,255,255,.06);
    letter-spacing:.04em;
  }
  .footer-links{display:flex;gap:32px;flex-wrap:wrap}
  .footer-links a{font-size:12.5px;letter-spacing:.04em;transition:color .2s var(--ease)}
  .footer-links a:hover{color:#fff}
  .footer-right{display:flex;align-items:center;gap:28px;flex-wrap:wrap}
  .footer-social{display:flex;gap:12px}
  .footer-social a{
    width:34px;height:34px;border-radius:50%;flex:none;
    display:flex;align-items:center;justify-content:center;
    border:1px solid rgba(255,255,255,.18);color:rgba(255,255,255,.7);
    transition:background .2s var(--ease),color .2s var(--ease),border-color .2s var(--ease);
  }
  .footer-social a:hover{background:#fff;color:#08080a;border-color:#fff}
  .footer-social svg{width:17px;height:17px;display:block}

  /* ---------- Floating CTA (mobile / 旧版維持) ---------- */
  .float-cta{
    position:fixed;left:0;right:0;bottom:0;z-index:40;
    background:rgba(255,255,255,.95);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
    border-top:1px solid var(--gray-300);padding:10px 16px;
    display:none;gap:10px;
  }
  .float-cta .btn{flex:1;padding:16px;font-size:15px}

  /* ---------- Always-on bottom LINE bar (ONECARAT signature) ---------- */
  .line-bar{
    position:fixed;left:0;right:0;bottom:0;z-index:45;
    background:var(--line);color:#fff;
    padding:16px 24px;text-align:center;
    font-weight:900;font-size:17px;letter-spacing:.04em;
    box-shadow:0 -8px 24px rgba(6,199,85,.25);
    transition:background .2s var(--ease),transform .2s var(--ease);
    display:flex;align-items:center;justify-content:center;gap:14px;
  }
  .line-bar:hover{background:var(--line-deep);transform:translateY(-1px)}
  .line-bar::before{
    content:"";width:24px;height:24px;flex-shrink:0;
    background:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'><path d='M12 2C6.48 2 2 5.86 2 10.6c0 2.74 1.6 5.17 4.09 6.78-.18.6-.65 2.2-.75 2.54-.12.43.16.43.34.32.14-.09 2.27-1.54 3.19-2.16.9.13 1.83.2 2.78.2c5.52 0 10-3.86 10-8.6S17.52 2 12 2z'/></svg>") no-repeat center/contain;
  }
  .line-bar-tap{
    display:inline-block;padding:4px 10px;border-radius:4px;
    background:rgba(255,255,255,.2);font-size:11px;font-weight:700;letter-spacing:.1em;
  }
  .float-cta .btn-secondary{
    background:#fff;color:var(--red);
    border:1.5px solid var(--red);
    box-shadow:0 2px 0 rgba(212,0,42,.15),0 6px 16px rgba(212,0,42,.08);
  }
  .float-cta .btn-secondary:hover{transform:translateY(-2px);background:var(--red-soft);border-color:var(--red-deep);color:var(--red-deep)}

  /* ---------- Animations ---------- */
  .fade-in{opacity:0;transform:translateY(20px);transition:opacity .8s var(--ease),transform .8s var(--ease)}
  .fade-in.in{opacity:1;transform:none}

  /* ========== PC fold最適化: 2カラム配置 (≥961px) ========== */
  @media (min-width:961px){
    .hero{padding:22px 0 32px}
    .hero-inner{
      display:grid;
      grid-template-columns:1.05fr 0.95fr;
      grid-template-areas:
        "head visual"
        "ctas visual"
        "strip strip"
        "trust trust";
      column-gap:48px;row-gap:12px;align-items:start;
    }
    .hero-head{grid-area:head;align-self:start}
    .hero-main{
      grid-area:visual;
      display:grid;grid-template-columns:1fr;grid-template-rows:auto auto;
      gap:14px;align-self:start;
    }
    .hero-main .hero-visual{justify-content:center}
    .hero-main .hero-metrics-panel{
      flex-direction:row;gap:18px;width:100%;
    }
    .hero-main .metric-card{
      flex:1;align-items:center;text-align:center;
      padding:12px 8px;border:1px solid var(--gray-100);border-radius:var(--r-md);
      background:rgba(255,255,255,.6);backdrop-filter:blur(6px);
    }
    .hero-ctas{grid-area:ctas;margin-top:8px}
    .hero-photo-strip{grid-area:strip;margin-top:18px}
    .hero-trust{grid-area:trust;margin-top:6px}
    /* PCでもスマホ幅をやや抑えて1画面fold収納 */
    .phone{width:min(190px,100%)}
    /* 巨大英字を少しだけ抑える (両カラム高さバランス) */
    .hero-en-mega{font-size:clamp(48px,5vw,76px)}
  }
  /* ---------- Responsive ---------- */
  @media (max-width: 960px){
    .header-nav{display:none}
    .nav-toggle{display:flex}
    .hero{padding:16px 0 20px}
    .hero-inner{gap:10px}
    .hero-head{text-align:left}
    .hero-badge{padding:4px 10px;font-size:10px}
    .hero-lead{font-size:14px;line-height:1.4;margin-top:8px}
    .hero h1{font-size:17px;line-height:1.4;margin-top:2px}
    .hero-en-mega{font-size:clamp(34px,10vw,58px);line-height:.92;margin-top:8px}
    /* 中部: スマホ｜メトリクス 2カラム死守 */
    .hero-main{grid-template-columns:0.85fr 1.15fr;gap:10px;align-items:center}
    .hero-visual{padding:0}
    .phone{width:min(135px,100%);padding:5px;border-radius:22px}
    .phone-notch{width:50px;height:13px;top:8px;border-radius:8px}
    .phone-screen{border-radius:17px}
    .live-top{top:22px;left:6px;right:6px}
    .live-badge{padding:2px 6px 2px 12px;font-size:7px}
    .live-badge::before{width:4px;height:4px;left:4px}
    .live-count{padding:2px 5px;font-size:6px}
    .live-count::before{width:6px;height:6px}
    .live-side{top:42px;right:5px;gap:3px}
    .viewer{width:14px;height:14px;border-width:1px}
    .viewer-more{font-size:6px;padding:1px 3px;border-radius:6px}
    .hearts-stream{bottom:54px;right:5px;width:30px;height:90px}
    .heart{font-size:11px}
    .heart.h2{font-size:9px}
    .heart.h3{font-size:13px}
    .heart.h5{font-size:11px}
    .live-bottom{bottom:6px;left:5px;right:5px;gap:2px}
    .comment{font-size:6px;padding:2px 5px;border-radius:7px;max-width:80%}
    .gift-bubble{font-size:6px;padding:2px 6px;border-radius:7px}
    /* メトリクスパネル: スマホでも黒バッジ＋シアン巨大数字を維持 */
    .hero-metrics-panel{gap:6px}
    .metric-card{gap:2px}
    .metric-label{padding:4px 11px;font-size:10px;letter-spacing:.03em}
    .metric-sub{font-size:9px;letter-spacing:.02em}
    .metric-value{font-size:clamp(28px,8vw,40px)}
    .metric-value small{font-size:.36em;margin-left:2px}
    /* スマホでは外側の浮遊バッジは非表示 */
    .badge-floor{display:none}
    /* 写真ストリップ: 1:1で薄く */
    .hero-photo-strip{grid-template-columns:repeat(5,1fr);gap:4px;margin-top:2px}
    .hero-photo-strip a{border-radius:6px;aspect-ratio:1/1}
    /* CTA: モバイルでも横並びでコンパクト */
    .hero-ctas{flex-direction:row;gap:6px;flex-wrap:nowrap;margin-top:6px}
    .hero-ctas .btn{flex:1;padding:11px 8px;font-size:12px;letter-spacing:0;width:auto}
    /* trust barはヒーロー外に隔離（fold圧迫を避ける） */
    .hero-trust{display:none}
    .opps-grid{grid-template-columns:1fr;gap:14px}
    .opp-feature{grid-column:span 1;grid-template-columns:1fr}
    .opp-feature .opp-img{min-height:200px}
    .opp-feature .opp-body{padding:24px 20px}
    .opp-card{padding:24px 20px}
    .premium-opps{padding:64px 20px}
    .stats-inner{grid-template-columns:repeat(2,1fr);gap:28px}
    section{padding:64px 20px}
    .reasons-grid{grid-template-columns:1fr;gap:14px}
    .reason{padding:28px 22px}
    .livers-grid{grid-template-columns:repeat(2,1fr)}
    .platform-icons{grid-template-columns:repeat(5,1fr);gap:18px 9px;max-width:460px}
    .picon-name{font-size:10px}
    .picon-art{border-radius:22%}
    .picon[data-rank]::before{font-size:9px;padding:4px 8px}
    .os-grid{grid-template-columns:1fr;gap:14px}
    .os-item{padding:20px 18px}
    .wyg-wrap{grid-template-columns:1fr;gap:32px}
    .reco-grid{grid-template-columns:1fr;gap:14px}
    .voice-grid{grid-template-columns:1fr;gap:18px}
    .cmp-table{font-size:12px}
    .cmp-table th,.cmp-table td{padding:12px 8px}
    .cmp-table tbody th{width:auto}
    .media-logos{gap:10px 14px}
    .ml{font-size:12px;padding:4px 10px}
    .qf-wrap{grid-template-columns:1fr;gap:32px;padding:28px 22px}
    .hero-tag.t2{bottom:50%;left:8px}
    .m-item{width:clamp(96px,32vw,140px)}
    .marquee-caption{font-size:10px;padding:6px 12px;bottom:10px}
    .marquee-track{animation-duration:40s}
    .campaign-inner{grid-template-columns:1fr;padding:56px 20px;gap:32px}
    .flow-grid{grid-template-columns:1fr;gap:14px}
    .flow-step:not(:last-child)::after{
      right:50%;top:auto;bottom:-14px;transform:translateX(50%) rotate(90deg);
    }
    .line-bar{padding:14px 20px;font-size:15px}
    body{padding-bottom:72px}
    .header-cta{display:none}
    .cta-final-buttons{flex-direction:column}
    .cta-final-buttons .btn{width:100%}
  }

  /* ========== ▼ 追加: 321ver 強化（スマホ最適化 / 写真帯2段 / 雑誌風） ========== */
  /* 雑誌風の見出しキッカー（赤いダッシュ） */
  .section-eyebrow::before,.marquee-eyebrow::before{
    content:"";display:inline-block;width:26px;height:2px;
    background:var(--red);vertical-align:middle;margin-right:10px;transform:translateY(-2px);
  }
  /* ライバー写真帯：見出し + 2段（上下で反対方向にスクロール） */
  .marquee-head{text-align:center;padding:56px 24px 30px}
  .marquee-eyebrow{font-family:Inter,sans-serif;color:var(--red);font-weight:900;font-size:13px;letter-spacing:.26em}
  .marquee-title{margin-top:10px;color:#fff;font-weight:900;line-height:1.3;font-size:clamp(24px,3.6vw,40px)}
  .marquee-title span{color:var(--red)}
  .liver-marquee{padding-bottom:50px}
  .marquee-viewport + .marquee-viewport{margin-top:14px}
  .marquee-track--rev{animation-name:m-scroll-rev}
  @keyframes m-scroll-rev{from{transform:translateX(-50%)}to{transform:translateX(0)}}
  .marquee-caption{position:static;transform:none;left:auto;bottom:auto;display:block;width:-moz-fit-content;width:fit-content;margin:30px auto 0}
  /* スマホ用ハンバーガーメニュー */
  .mobile-menu{display:none}
  .nav-toggle span,.nav-toggle span::before,.nav-toggle span::after{transition:transform .25s var(--ease),top .25s var(--ease),background .2s var(--ease)}
  /* 超小型端末 (iPhone SE等 ≤375px) 用ヒーロー保護 */
  @media (max-width:480px){
    .hero{padding:12px 0 16px}
    .hero-inner{padding:0 14px;gap:8px}
    .hero-badge{font-size:9px;padding:3px 9px}
    .hero-lead{font-size:13px;margin-top:6px}
    .hero h1{font-size:15px}
    .hero-en-mega{font-size:clamp(28px,9vw,40px);margin-top:6px}
    .hero-main{grid-template-columns:0.85fr 1.15fr;gap:8px}
    .phone{width:min(115px,100%);padding:4px;border-radius:18px}
    .phone-notch{width:42px;height:11px;top:6px;border-radius:7px}
    .phone-screen{border-radius:14px}
    .live-top{top:18px;left:5px;right:5px}
    .live-badge{font-size:6px;padding:2px 5px 2px 11px}
    .live-badge::before{width:3px;height:3px;left:3px}
    .live-count{font-size:5px;padding:2px 4px}
    .live-count::before{width:5px;height:5px}
    .live-side{top:34px;right:4px;gap:2px}
    .viewer{width:12px;height:12px;border-width:1px}
    .viewer-more{font-size:5px;padding:1px 2px;border-radius:5px}
    .hearts-stream{bottom:42px;right:3px;width:24px;height:70px}
    .heart{font-size:9px}
    .live-bottom{bottom:5px;left:3px;right:3px;gap:2px}
    .comment{font-size:5px;padding:1px 4px;border-radius:6px;max-width:80%}
    .gift-bubble{font-size:5px;padding:1px 5px;border-radius:6px}
    .metric-label{padding:3px 9px;font-size:9px}
    .metric-sub{font-size:8px}
    .metric-value{font-size:clamp(22px,7vw,30px)}
    .hero-metrics-panel{gap:5px}
    .hero-photo-strip{gap:3px}
    .hero-photo-strip a{border-radius:5px}
    .hero-ctas{gap:5px;margin-top:4px}
    .hero-ctas .btn{padding:10px 6px;font-size:11px;letter-spacing:0;flex:1;width:auto}
  }
  @media (max-width:960px){
    .mobile-menu{display:block;max-height:0;overflow:hidden;background:rgba(255,255,255,.98);border-top:1px solid var(--gray-100);transition:max-height .32s var(--ease)}
    .site-header.open .mobile-menu{max-height:520px}
    .mobile-menu nav{display:flex;flex-direction:column;padding:6px 24px 18px}
    .mobile-menu nav a{padding:15px 2px;font-size:15px;font-weight:700;color:var(--gray-900);border-bottom:1px solid var(--gray-100)}
    .mobile-menu nav a.header-cta{display:inline-flex;margin-top:16px;border-bottom:none;justify-content:center;color:#fff}
    .site-header.open .nav-toggle span{background:transparent}
    .site-header.open .nav-toggle span::before{top:0;transform:rotate(45deg)}
    .site-header.open .nav-toggle span::after{top:0;transform:rotate(-45deg)}
  }
  /* ========== ▲ 追加ここまで ========== */
</style>
  <?php wp_head(); ?>
</head>
<body>

<!-- ========== Header ========== -->
<header class="site-header">
  <div class="header-inner">
    <a href="#top" class="logo">
      <img src="https://live-labo.jp/wp/wp-content/themes/livelabonew/images/logo.svg" alt="Live-Labo">
    </a>
    <nav class="header-nav">
      <a href="#reasons">選ばれる理由</a>
      <a href="#platforms">対応アプリ</a>
      <a href="#livers">所属ライバー</a>
      <a href="#voice">ライバーの声</a>
      <a href="#premium">特典</a>
      <a href="#faq">FAQ</a>
    </nav>
    <a href="https://lin.ee/vMcAZIJ" class="header-cta">LINEで無料相談</a>
    <button class="nav-toggle" aria-label="メニュー" aria-expanded="false" aria-controls="mobileMenu"><span></span></button>
  </div>
  <div class="mobile-menu" id="mobileMenu">
    <nav>
      <a href="#reasons">選ばれる理由</a>
      <a href="#platforms">対応アプリ</a>
      <a href="#livers">所属ライバー</a>
      <a href="#voice">ライバーの声</a>
      <a href="#premium">特典</a>
      <a href="#faq">FAQ</a>
      <a href="https://lin.ee/vMcAZIJ" class="header-cta">LINEで無料相談</a>
    </nav>
  </div>
</header>

<!-- ========== Hero ========== -->
<section class="hero" id="top">
  <div class="hero-inner">

    <!-- ① 上部: 見出しブロック (Live-Laboオリジナルキャッチ) -->
    <div class="hero-head">
      <p class="hero-lead">次世代のインフルエンサーを育成する</p>
      <h1>日本トップクラスの<span class="accent">ライバー事務所</span></h1>
      <p class="hero-en-mega">LIVE YOUR<br><span class="glow">LIGHT</span>.</p>
    </div>

    <!-- ② 中部: 左スマホモック ｜ 右メトリクスパネル -->
    <div class="hero-main">
      <div class="hero-visual">
        <div class="phone-stage">
          <!-- スマホモックアップ：ライブ配信中の画面 -->
          <div class="phone" aria-label="ライブ配信画面のイメージ">
            <span class="phone-notch" aria-hidden="true"></span>
            <div class="phone-screen">
              <img class="phone-bg" src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%82%8F%E3%82%89%E3%81%97%E3%80%82.jpg" alt="">
              <!-- 配信UI上部 -->
              <div class="live-top">
                <span class="live-badge">LIVE</span>
                <span class="live-count">12,547</span>
              </div>
              <!-- 視聴者アバター -->
              <div class="live-side">
                <img class="viewer" src="https://live-labo.jp/wp/wp-content/uploads/2024/12/%E3%81%82%E3%81%AE%E2%91%A1.jpg" alt="">
                <img class="viewer" src="https://live-labo.jp/wp/wp-content/uploads/2022/03/%E3%82%86%E3%81%84%E3%81%93%E3%82%8D.jpg" alt="">
                <img class="viewer" src="https://live-labo.jp/wp/wp-content/uploads/2025/01/IMG_9545-%E3%81%AA%E3%82%8B%E3%81%BF.jpeg" alt="">
                <span class="viewer-more">+128</span>
              </div>
              <!-- 浮かぶハート -->
              <div class="hearts-stream" aria-hidden="true">
                <span class="heart h1">♥</span>
                <span class="heart h2">♥</span>
                <span class="heart h3">♥</span>
                <span class="heart h4">♥</span>
                <span class="heart h5">♥</span>
              </div>
              <!-- 下部: コメント + ギフト -->
              <div class="live-bottom">
                <div class="comment">いつも見てます！</div>
                <div class="comment">今日もかわいい</div>
                <div class="gift-bubble">GIFT × 3</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- ONECARAT準拠 黒バッジ + サブ + 巨大シアン数字 -->
      <aside class="hero-metrics-panel" aria-label="主要実績">
        <div class="metric-card">
          <span class="metric-label">平均月収</span>
          <span class="metric-sub">3ヶ月継続ライバー実績</span>
          <span class="metric-value">36<small>万円</small></span>
        </div>
        <div class="metric-card">
          <span class="metric-label">最高月収</span>
          <span class="metric-sub">所属TOPライバー実績</span>
          <span class="metric-value">1000<small>万円+</small></span>
        </div>
      </aside>
    </div>

    <!-- ③ CTA -->
    <div class="hero-ctas">
      <a href="https://lin.ee/vMcAZIJ" class="btn btn-primary btn-arrow">LINEで無料相談</a>
      <a href="#reasons" class="btn btn-ghost btn-arrow">選ばれる理由を見る</a>
    </div>

    <!-- ④ 下部: 所属ライバー写真ストリップ (ONECARATスマホ下端の真似) -->
    <div class="hero-photo-strip" aria-label="所属ライバー">
      <a href="#livers"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/12/%E3%81%82%E3%81%AE%E2%91%A1.jpg" alt="あの" loading="lazy"></a>
      <a href="#livers"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/03/%E3%82%86%E3%81%84%E3%81%93%E3%82%8D.jpg" alt="ゆいころ" loading="lazy"></a>
      <a href="#livers"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/01/IMG_9545-%E3%81%AA%E3%82%8B%E3%81%BF.jpeg" alt="なるみ" loading="lazy"></a>
      <a href="#livers"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/06/%E3%81%95%E3%82%84%E3%81%8B-scaled.jpeg" alt="さやか" loading="lazy"></a>
      <a href="#livers"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/02/%E3%81%8D%E3%81%84%E3%81%A1.jpg" alt="きいち" loading="lazy"></a>
    </div>

  </div>
</section>

<!-- ========== Liver Marquee (左に流れるライバー写真ストリップ) ========== -->
<section class="liver-marquee" aria-label="活躍中の所属ライバー">
  <div class="marquee-head">
    <span class="marquee-eyebrow">ACTIVE LIVERS</span>
    <h2 class="marquee-title">毎日、どこかで<span>輝いてる</span>。</h2>
  </div>
  <div class="marquee-viewport">
    <div class="marquee-track">
      <!-- セット1 -->
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%82%8F%E3%82%89%E3%81%97%E3%80%82.jpg" alt="わらし。" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/12/%E3%81%82%E3%81%AE%E2%91%A1.jpg" alt="あの" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/06/%E3%81%95%E3%82%84%E3%81%8B-scaled.jpeg" alt="さやか" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/03/%E3%82%86%E3%81%84%E3%81%93%E3%82%8D.jpg" alt="ゆいころ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%83%A6%E3%82%A6%E3%82%BF.jpg" alt="遊汰様" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/01/IMG_9545-%E3%81%AA%E3%82%8B%E3%81%BF.jpeg" alt="なるみ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/03/%E3%81%8A%E3%81%A8%E3%81%86%E3%81%B5-scaled.jpeg" alt="おとうふ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/04/%E3%81%8A%E5%A4%A9-scaled.jpeg" alt="お天" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/02/%E3%81%8D%E3%81%84%E3%81%A1.jpg" alt="きいち" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/09/%E3%83%AC%E3%82%A4%E3%83%9F.jpg" alt="レイミ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/10/yanchan-scaled.jpeg" alt="やんちゃん" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/09/%E3%81%B4%E3%81%B4%E3%82%80-scaled.jpeg" alt="ぴぴむ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/02/%E3%81%97%E3%82%93%E3%81%98%E3%82%85.jpeg" alt="しんじゅ" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/07/%E3%82%86%E3%81%8D%E3%81%A1%E3%82%83%E3%82%93.jpeg" alt="ゆきちゃん" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/12/Achan-e1703232526958.jpeg" alt="Aちゃん" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/06/%E9%AC%BC%E5%AB%81Luna.jpeg" alt="鬼嫁Luna" loading="lazy"></a>
      <!-- セット2 (シームレスループ用に完全複製 — aria-hiddenでスクリーンリーダーから除外) -->
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%82%8F%E3%82%89%E3%81%97%E3%80%82.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/12/%E3%81%82%E3%81%AE%E2%91%A1.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/06/%E3%81%95%E3%82%84%E3%81%8B-scaled.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/03/%E3%82%86%E3%81%84%E3%81%93%E3%82%8D.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%83%A6%E3%82%A6%E3%82%BF.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/01/IMG_9545-%E3%81%AA%E3%82%8B%E3%81%BF.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/03/%E3%81%8A%E3%81%A8%E3%81%86%E3%81%B5-scaled.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/04/%E3%81%8A%E5%A4%A9-scaled.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/02/%E3%81%8D%E3%81%84%E3%81%A1.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/09/%E3%83%AC%E3%82%A4%E3%83%9F.jpg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/10/yanchan-scaled.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/09/%E3%81%B4%E3%81%B4%E3%82%80-scaled.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/02/%E3%81%97%E3%82%93%E3%81%98%E3%82%85.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/07/%E3%82%86%E3%81%8D%E3%81%A1%E3%82%83%E3%82%93.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/12/Achan-e1703232526958.jpeg" alt="" loading="lazy"></a>
      <a href="https://live-labo.jp/liver/" class="m-item" aria-hidden="true" tabindex="-1"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/06/%E9%AC%BC%E5%AB%81Luna.jpeg" alt="" loading="lazy"></a>
    </div>
  </div>
</section>

<!-- ========== Activity Tags (ライバーが目指せる7フィールド) ========== -->
<section class="activity-tags">
  <div class="section-inner">
    <ul class="atag-list">
      <li>IDOL</li>
      <li>INFLUENCER</li>
      <li>ACTOR</li>
      <li>MODEL</li>
      <li>ARTIST</li>
      <li>TALENT</li>
      <li>MEDIA</li>
    </ul>
  </div>
</section>

<!-- ========== Trust Strip ========== -->
<section class="media-strip">
  <div class="section-inner">
    <p class="media-eyebrow">TRUSTED PARTNERS — 安心の取引・連携先</p>
    <div class="media-logos">
      <span class="ml">Pococha 公認</span>
      <span class="ml">TikTok LIVE 提携</span>
      <span class="ml">17LIVE 提携</span>
      <span class="ml">提携税理士事務所</span>
      <span class="ml">提携法律事務所</span>
    </div>
  </div>
</section>

<!-- ========== Stats ========== -->
<!-- Yokouchiさんへ: 「500+」は実数に置き換えてください。最低限の根拠が無い数字は景表法上避けてください -->
<section class="stats">
  <div class="stats-inner">
    <div class="stat">
      <div class="stat-num">100<small>%</small></div>
      <div class="stat-label">報酬還元率</div>
    </div>
    <div class="stat">
      <div class="stat-num">1<small>位</small></div>
      <div class="stat-label">Pococha マンスリー多数輩出</div>
    </div>
    <div class="stat">
      <div class="stat-num">3<small>ヶ月</small></div>
      <div class="stat-label">未経験→S帯ランク達成</div>
    </div>
    <div class="stat">
      <div class="stat-num">0<small>円</small></div>
      <div class="stat-label">初期費用・契約料</div>
    </div>
  </div>
</section>

<!-- ========== Reasons ========== -->
<section class="reasons" id="reasons">
  <div class="section-inner">
    <span class="section-eyebrow">Why Live-Labo</span>
    <h2 class="section-title"><span class="accent nb">"本物のサポート"</span><span class="nb">がここにある</span></h2>
    <p class="section-lead">「数字」だけじゃなく「人」を育てる。Live-Laboが築き上げてきた、5つの強みです。</p>
    <div class="reasons-grid">

      <article class="reason fade-in">
        <div class="reason-num">REASON 01</div>
        <h3>Pocochaに圧倒的に強い</h3>
        <p>Pococha歴代1位ライバーを多数輩出。マンスリー1位経験者が在籍しているからこそ、リアルな成功ノウハウを共有できます。</p>
      </article>

      <article class="reason fade-in">
        <div class="reason-num">REASON 02</div>
        <h3>還元率100%・余計な搾取なし</h3>
        <p>Pocochaの場合、報酬ダイヤを100%ライバーへ。悪徳事務所にありがちな"見えない手数料"は一切いただきません。</p>
      </article>

      <article class="reason fade-in">
        <div class="reason-num">REASON 03</div>
        <h3>住所提供サービス</h3>
        <p>ファンレター・プライズの受取に事務所住所が使えます。自宅住所を公開せず、安心して活動できます。</p>
      </article>

      <article class="reason fade-in">
        <div class="reason-num">REASON 04</div>
        <h3>確定申告サポート</h3>
        <p>提携税理士事務所を最大半額以下で利用可能。「お金の手続き」は丸ごとお任せください。</p>
      </article>

      <article class="reason fade-in">
        <div class="reason-num">REASON 05</div>
        <h3>未経験から3ヶ月でS帯</h3>
        <p>初配信前から徹底マネジメント。実績ある専属マネージャーが、あなたの個性に合わせた配信スタイルを一緒に作ります。</p>
      </article>

    </div>
  </div>
</section>

<!-- ========== Other Support (icon grid) ========== -->
<section class="other-support">
  <div class="section-inner">
    <div class="os-heading">
      <span class="section-eyebrow">Other Support</span>
      <h2 class="section-title"><span class="nb">さらに、</span><span class="accent nb">6つのサポート</span><span class="nb">を完備</span></h2>
      <p class="section-lead">配信だけじゃない。ライバーとしての"活動全般"を支える各種オプションを、すべて無料または優待価格でご利用いただけます。</p>
    </div>
    <div class="os-grid">
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="14" stroke="currentColor" stroke-width="1.5"/><path d="M10 16h12M16 10v12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 13l8 6M20 13l-8 6" stroke="currentColor" stroke-width="1" stroke-linecap="round" opacity=".5"/></svg></div>
        <div class="os-label">オリジナル<br>グッズ制作</div>
      </div>
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><rect x="5" y="9" width="22" height="14" rx="2" stroke="currentColor" stroke-width="1.8"/><path d="M5 11l11 7 11-7" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></div>
        <div class="os-label">郵便転送<br>サービス</div>
      </div>
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><path d="M16 27s-9-5.5-9-13a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 7.5-9 13-9 13z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></div>
        <div class="os-label">オフ会・<br>イベント開催</div>
      </div>
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="11" r="5" stroke="currentColor" stroke-width="1.8"/><path d="M6 27c0-5.5 4.5-10 10-10s10 4.5 10 10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="23" cy="9" r="2" fill="currentColor"/></svg></div>
        <div class="os-label">タレント活動<br>メディア出演</div>
      </div>
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><path d="M16 4l11 5v8c0 6-4.5 10-11 11C9.5 27 5 23 5 17V9z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M11 16l4 4 7-8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        <div class="os-label">弁護士による<br>法務相談</div>
      </div>
      <div class="os-item">
        <div class="os-icon"><svg viewBox="0 0 32 32" fill="none"><rect x="7" y="5" width="18" height="22" rx="2" stroke="currentColor" stroke-width="1.8"/><rect x="11" y="9" width="10" height="4" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="18" r="1" fill="currentColor"/><circle cx="16" cy="18" r="1" fill="currentColor"/><circle cx="20" cy="18" r="1" fill="currentColor"/><circle cx="12" cy="22" r="1" fill="currentColor"/><circle cx="16" cy="22" r="1" fill="currentColor"/><circle cx="20" cy="22" r="1" fill="currentColor"/></svg></div>
        <div class="os-label">税理士による<br>確定申告</div>
      </div>
    </div>
  </div>
</section>

<!-- ========== What You Get ========== -->
<section class="what-you-get">
  <div class="section-inner">
    <div class="wyg-wrap">
      <div class="wyg-text">
        <span class="section-eyebrow">What You Get</span>
        <h2 class="section-title"><span class="nb">ライブ配信で</span><span class="accent nb">得られる4つのこと</span></h2>
        <p class="section-lead">単なる収入アップだけじゃない。あなたの人生に、新しい価値をもたらします。</p>
      </div>
      <ul class="wyg-list">
        <li><span class="wyg-num">01</span><div><h3>"好き"で稼ぐ力</h3><p>趣味・特技・キャラクター — あなたを"そのまま"商品にできます。</p></div></li>
        <li><span class="wyg-num">02</span><div><h3>新しい自分の発見</h3><p>配信を通じて気づかなかった魅力や強みが見つかります。</p></div></li>
        <li><span class="wyg-num">03</span><div><h3><span class="nb">たくさんの</span><span class="nb">仲間との出会い</span></h3><p>所属ライバー同士のコミュニティ・コラボ配信で、一生の仲間ができます。</p></div></li>
        <li><span class="wyg-num">04</span><div><h3>自由な時間と場所</h3><p>満員電車も、通勤もなし。スマホ1台で、自分のペースで働けます。</p></div></li>
      </ul>
    </div>
  </div>
</section>

<!-- ========== Premium Opportunities (業界コネクションでしか掴めない大舞台) ========== -->
<section class="premium-opps" id="premium">
  <div class="section-inner">
    <span class="section-eyebrow">Premium Opportunities</span>
    <h2 class="section-title"><span class="nb">配信の先にある</span><span class="accent nb">"プレミアム特典"</span></h2>
    <p class="section-lead">Live-Laboは業界トップクラスの提携先ネットワークを保有。トップランカーには、配信だけでは届かない大舞台への扉が開かれます。</p>

    <div class="opps-grid">
      <article class="opp-card opp-feature">
        <div class="opp-img"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/shikyushiki-v2.jpg" alt="プロ野球始球式 出演中の所属ライバー" loading="lazy"></div>
        <div class="opp-body">
          <span class="opp-tag">SPORTS</span>
          <h3>プロ野球 始球式 出演権</h3>
          <p>Live-Labo提携球団の試合で、人気ライバーが始球式に立つチャンス。マウンドからファンへ"配信を超えた瞬間"を届けられます。</p>
        </div>
      </article>

      <article class="opp-card">
        <div class="opp-icon">
          <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="6" width="24" height="16" rx="2"/><path d="M10 26h12M16 22v4"/></svg>
        </div>
        <span class="opp-tag">MEDIA</span>
        <h3>TV番組・CM出演</h3>
        <p>地上波バラエティ、配信ドラマ、企業CMへの出演オファー。提携キャスティング会社と連携。</p>
      </article>

      <article class="opp-card">
        <div class="opp-icon">
          <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="20" height="24" rx="2"/><path d="M10 9h12M10 14h12M10 19h8"/></svg>
        </div>
        <span class="opp-tag">PUBLISHING</span>
        <h3>雑誌掲載・<br>写真集出版</h3>
        <p>女性誌・カルチャー誌への掲載、写真集の企画から発売までトータルプロデュース。</p>
      </article>

      <article class="opp-card">
        <div class="opp-icon">
          <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 11l11-7 11 7v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z"/><path d="M11 27V18h10v9"/></svg>
        </div>
        <span class="opp-tag">GOODS</span>
        <h3>オリジナルグッズ<br>制作・販売</h3>
        <p>あなたブランドのアパレル・アクセサリーを企画から販売チャネルまで構築。</p>
      </article>

    </div>

    <p class="opps-note">※ 上記特典には、Pococha をはじめとする各プラットフォーム主催イベントのプライズとして獲得・提供されるものを含みます。適用は所属ライバーのランク・実績に応じて変動します。</p>
  </div>
</section>

<!-- ========== Livers ========== -->
<section class="livers" id="livers">
  <div class="section-inner">
    <span class="section-eyebrow">Active Livers</span>
    <h2 class="section-title"><span class="nb">活躍中の</span><span class="accent nb">所属ライバー</span></h2>
    <p class="section-lead">Pococha・TikTok LIVE・17LIVEなど、複数プラットフォームでTOPランカーを多数輩出。</p>
    <div class="livers-grid" id="liversGrid">
      <!-- ===== TOP 8（初期表示）= 事務所内ランキング順 1〜8 ===== -->
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%82%8F%E3%82%89%E3%81%97%E3%80%82.jpg" alt="わらし。" loading="lazy"></div>
        <div class="liver-name">𖤐 わらし。🐻‍❄️໒꒱·̩͙</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/12/%E3%81%82%E3%81%AE%E2%91%A1.jpg" alt="あの" loading="lazy"></div>
        <div class="liver-name">あの</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/01/IMG_9545-%E3%81%AA%E3%82%8B%E3%81%BF.jpeg" alt="なるみ" loading="lazy"></div>
        <div class="liver-name">⋆✦🩵なるみ🩵⋆✦</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/03/%E3%82%86%E3%81%84%E3%81%93%E3%82%8D.jpg" alt="ゆいころ" loading="lazy"></div>
        <div class="liver-name">ゆいころ⩊💰</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/06/%E3%81%95%E3%82%84%E3%81%8B-scaled.jpeg" alt="さやか" loading="lazy"></div>
        <div class="liver-name">さやか🖤🐷</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/07/%E3%82%86%E3%81%8D%E3%81%A1%E3%82%83%E3%82%93.jpeg" alt="ゆきちゃん" loading="lazy"></div>
        <div class="liver-name">ゆきちゃん☃️</div>      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2021/12/%E3%83%A6%E3%82%A6%E3%82%BF.jpg" alt="遊汰様" loading="lazy"></div>
        <div class="liver-name">遊汰様🌙✞</div>
      </div>
      <div class="liver-card">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/05/%E3%81%B4%E3%81%AE.jpeg" alt="ぴの" loading="lazy"></div>
        <div class="liver-name">ぴの</div>      </div>
      <!-- ===== 追加（「さらに表示」で展開）= ランキング9〜 → 未ランク（ランダム）→ 非実写は最後 ===== -->
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/09/%E3%83%AC%E3%82%A4%E3%83%9F.jpg" alt="レイミ" loading="lazy"></div>
        <div class="liver-name">レイミ🕊️🎙️</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/02/%E3%81%8D%E3%81%84%E3%81%A1.jpg" alt="きいち" loading="lazy"></div>
        <div class="liver-name">きいち</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/emirin-monroe.jpg" alt="えみりんモンロー" loading="lazy"></div>
        <div class="liver-name">💄えみりん🎙️モンロー👠</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/04/%E3%81%8A%E5%A4%A9-scaled.jpeg" alt="お天" loading="lazy"></div>
        <div class="liver-name">お天🍃</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/02/S__8396837.jpg" alt="みみみ" loading="lazy"></div>
        <div class="liver-name">🖤みみみ🧸💋</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/palm.jpg" alt="パルム" loading="lazy"></div>
        <div class="liver-name">パルム🍨💖</div>      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/03/%E3%81%8A%E3%81%A8%E3%81%86%E3%81%B5-scaled.jpeg" alt="おとうふ" loading="lazy"></div>
        <div class="liver-name">おとうふ☁️🎀</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/06/%E9%AC%BC%E5%AB%81Luna.jpeg" alt="鬼嫁Luna" loading="lazy"></div>
        <div class="liver-name">鬼嫁Luna</div>      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2026/03/%E3%81%AF%E3%81%AB-scaled.jpeg" alt="はに" loading="lazy"></div>
        <div class="liver-name">はに</div>      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/orenoreo.jpg" alt="おれのれお" loading="lazy"></div>
        <div class="liver-name">おれのれお</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/kurumon.jpg" alt="くるもん" loading="lazy"></div>
        <div class="liver-name">🥂🐻卍くるもん卍🐻🥂</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/renamero.jpg" alt="れなめろ" loading="lazy"></div>
        <div class="liver-name">れなめろ</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/05/%E7%A9%BA%E5%B8%8C%E3%82%8C%E3%81%84%E3%81%AA%E2%91%A1.jpg" alt="空希れいな" loading="lazy"></div>
        <div class="liver-name">空希れいな</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2022/11/S__32292884.jpg" alt="カエすも" loading="lazy"></div>
        <div class="liver-name">カエすも</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2025/10/S__98770953.jpg" alt="かりんとう" loading="lazy"></div>
        <div class="liver-name">かりんとう</div>      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/kumochan.jpg" alt="雲ちゃん" loading="lazy"></div>
        <div class="liver-name">雲ちゃん</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/hazuta.jpg" alt="はづた" loading="lazy"></div>
        <div class="liver-name">はづた</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2023/10/yanchan-scaled.jpeg" alt="みきやん" loading="lazy"></div>
        <div class="liver-name">みきやん</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/namu.jpg" alt="なむ" loading="lazy"></div>
        <div class="liver-name">なむ🪄ྀིᝰꪑ</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/karisma-shoma-v2.jpg" alt="カリスマしょーま" loading="lazy"></div>
        <div class="liver-name">🐱カリスマしょーま🍻</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/challenge-kou.jpg" alt="チャレンジこう" loading="lazy"></div>
        <div class="liver-name">チャレンジこう</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/shunshun.jpg" alt="しゅんしゅん" loading="lazy"></div>
        <div class="liver-name">しゅんしゅん</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/mauchi.jpg" alt="まぅち" loading="lazy"></div>
        <div class="liver-name">まぅち</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/koyutan-v2.jpg" alt="こゆたん" loading="lazy"></div>
        <div class="liver-name">こゆたん🐱🎸あまねこゆ</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/tomaru-akari.jpg" alt="都丸あかり" loading="lazy"></div>
        <div class="liver-name">都丸あかり🦙。</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/itsuki-v2.jpg" alt="伊月" loading="lazy"></div>
        <div class="liver-name">𓂃𑁍ྀ伊月🥀ྀི🐕‍🦺ྀི</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://live-labo.jp/wp/wp-content/uploads/2024/06/MAHO%E2%91%A0.jpg" alt="MAHO" loading="lazy"></div>
        <div class="liver-name">🔲🔳 M A😴H O 🔳🔲《は》</div>
      </div>
      <div class="liver-card is-extra">
        <div class="liver-photo"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/livers/agari.jpg" alt="あがりちゃん" loading="lazy"></div>
        <div class="liver-name">🍥あがりちゃん🍥</div>
      </div>
    </div>
    <div class="livers-more">
      <button class="liver-more-btn" id="liversMoreBtn" type="button" aria-expanded="false" aria-controls="liversGrid">
        <span class="lmb-text">さらに表示する</span>
        <span class="lmb-icon" aria-hidden="true"></span>
      </button>
    </div>
  </div>
</section>
<script>
  /* ライバー一覧：さらに表示トグル（このセクション専用・他に影響なし） */
  (function(){
    var grid=document.getElementById('liversGrid');
    var btn=document.getElementById('liversMoreBtn');
    if(!grid||!btn)return;
    var txt=btn.querySelector('.lmb-text');
    btn.addEventListener('click',function(){
      var expanded=grid.classList.toggle('is-expanded');
      btn.setAttribute('aria-expanded',expanded?'true':'false');
      if(txt)txt.textContent=expanded?'閉じる':'さらに表示する';
      if(!expanded){
        var sec=document.getElementById('livers');
        if(sec)sec.scrollIntoView({behavior:'smooth',block:'start'});
      }
    });
  })();
</script>

<!-- ========== Platforms (PARTNER wall) ========== -->
<section class="platforms" id="platforms">
  <div class="section-inner">
    <div class="platforms-head">
      <h2 class="platforms-title">PARTNER</h2>
      <p class="platforms-sub">提携先プラットフォーム</p>
      <p class="platforms-lead">主要配信アプリすべてに対応。TikTok LIVE・Pococha を中心に、あなたに合ったアプリでデビューできます。</p>
    </div>
    <div class="platform-icons">
      <a class="picon" title="TikTok LIVE">
        <div class="picon-art" aria-hidden="true"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/logos/app-tiktok.png" alt="TikTok LIVE" class="picon-img" loading="lazy"></div>
        <span class="picon-name">TikTok LIVE</span>
      </a>
      <a class="picon" title="Pococha">
        <div class="picon-art" aria-hidden="true"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/logos/app-pococha.png" alt="Pococha" class="picon-img" loading="lazy"></div>
        <span class="picon-name">Pococha</span>
      </a>
      <a class="picon" title="17LIVE">
        <div class="picon-art" aria-hidden="true"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/logos/app-17live.png" alt="17LIVE" class="picon-img" loading="lazy"></div>
        <span class="picon-name">17LIVE</span>
      </a>
      <a class="picon" title="ColorSing">
        <div class="picon-art" aria-hidden="true"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/logos/app-colorsing.jpg" alt="ColorSing" class="picon-img" loading="lazy"></div>
        <span class="picon-name">ColorSing</span>
      </a>
      <a class="picon" title="BIGO LIVE">
        <div class="picon-art" aria-hidden="true"><img src="https://atomtokyo.github.io/live-labo-lp-preview/assets/logos/app-bigo.jpg" alt="BIGO LIVE" class="picon-img" loading="lazy"></div>
        <span class="picon-name">BIGO LIVE</span>
      </a>
    </div>
    <p class="platforms-note">※ ロゴは各社の商標です。Live-Laboは全配信アプリのオフィシャル提携または公認ライバー事務所として活動しています。</p>
  </div>
</section>

<!-- ========== Recommendation (こんな方におすすめ) ========== -->
<section class="recommendation">
  <div class="section-inner">
    <span class="section-eyebrow">Recommendation</span>
    <h2 class="section-title"><span class="nb">こんな方に</span><span class="accent nb">特におすすめ</span></h2>
    <p class="section-lead">少しでも当てはまったら、まずは無料相談から。あなたに合った働き方をご提案します。</p>
    <div class="reco-grid">
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="16" r="11"/><path d="M16 9v7l4 3"/></svg></div>
        <h3>スキマ時間を活用したい</h3>
        <p>家事の合間・通学前・寝る前の30分から。あなたのスケジュールに合わせて配信できます。</p>
      </div>
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4v24M11 9h7a4 4 0 0 1 0 8h-6a4 4 0 0 0 0 8h8"/></svg></div>
        <h3>収入をもう一本増やしたい</h3>
        <p>本業＋副業として、月数万円〜数十万円。会社員・主婦の方が安定して稼げています。</p>
      </div>
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="13" y="4" width="6" height="14" rx="3"/><path d="M9 14a7 7 0 0 0 14 0M16 21v6M11 27h10"/></svg></div>
        <h3>夢・目標を叶えたい</h3>
        <p>歌手・タレント・モデル — ライブ配信は最短のステップ。実際にメジャーデビューしたライバーも。</p>
      </div>
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="11" r="4"/><circle cx="22" cy="11" r="4"/><path d="M3 26c0-4 3-7 7-7s7 3 7 7M15 26c0-4 3-7 7-7s7 3 7 7"/></svg></div>
        <h3>新しい仲間がほしい</h3>
        <p>所属ライバー専用コミュニティで、コラボ・情報交換・オフ会。リアルでも繋がれます。</p>
      </div>
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3l3.5 8.5L28 13l-7 6 2 9-7-5-7 5 2-9-7-6 8.5-1.5z"/></svg></div>
        <h3>有名になりたい・推されたい</h3>
        <p>SNS総フォロワー10万人を超えるトップライバーも在籍。あなたも"推される側"へ。</p>
      </div>
      <div class="reco-card">
        <div class="reco-icon"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 5L3 12l13 7 13-7zM7 16v7l9 5 9-5v-7"/></svg></div>
        <h3>未経験から始めたい</h3>
        <p>初配信からの教育プログラム完備。マネージャーが付きっきりで伴走します。</p>
      </div>
    </div>
  </div>
</section>

<!-- ========== Comparison Table ========== -->
<section class="comparison">
  <div class="section-inner">
    <span class="section-eyebrow">Comparison</span>
    <h2 class="section-title"><span class="nb">他社事務所との</span><span class="accent nb">徹底比較</span></h2>
    <p class="section-lead">数字だけでなく、サポート品質・透明性で選ばれる理由。</p>
    <div class="cmp-table-wrap">
      <table class="cmp-table">
        <thead>
          <tr>
            <th></th>
            <th class="us">Live-Labo</th>
            <th>業界一般</th>
            <th>個人活動<br>（無所属）</th>
          </tr>
        </thead>
        <tbody>
          <tr><th>還元率</th><td class="us"><strong>100%</strong></td><td>60〜80%</td><td>50〜65%</td></tr>
          <tr><th>初期費用</th><td class="us">0円</td><td>0〜数万円</td><td>機材代自己負担</td></tr>
          <tr><th>専属マネージャー</th><td class="us">✓ 全員に配置</td><td>△ 上位ライバーのみ</td><td>—</td></tr>
          <tr><th>住所提供サービス</th><td class="us">✓ 無料</td><td>有料 or 限定的</td><td>—</td></tr>
          <tr><th>確定申告サポート</th><td class="us">✓ 提携税理士優待</td><td>—</td><td>—</td></tr>
          <tr><th>配信機材</th><td class="us">✓ 無料レンタル</td><td>有料 or 自己負担</td><td>自己負担</td></tr>
          <tr><th>教育プログラム</th><td class="us">✓ 未経験向け完備</td><td>△ 限定的</td><td>—</td></tr>
        </tbody>
      </table>
      <p class="cmp-note">※ 公開情報および当社調査に基づく一般的な傾向です。個別の事務所により条件は異なります。</p>
    </div>
  </div>
</section>

<!-- ========== Voice (Testimonials) ========== -->
<section class="voice">
  <div class="section-inner">
    <span class="section-eyebrow">Voice</span>
    <h2 class="section-title"><span class="nb">所属ライバーの</span><span class="accent nb">リアルな声</span></h2>
    <p class="section-lead">実際にLive-Laboで活動するライバーから届いた、率直な感想です。</p>
    <div class="voice-grid">
      <article class="voice-card">
        <div class="voice-quote">"未経験から3ヶ月でS帯に。<br>マネージャーの存在が大きすぎる。"</div>
        <div class="voice-meta">
          <div class="voice-avatar" aria-hidden="true">R.S</div>
          <div><strong>R.S さん</strong><span>Pococha / 在籍3年</span></div>
        </div>
        <p class="voice-body">最初は配信すら怖かったのに、専属マネージャーが企画から雑談ネタまで一緒に考えてくれて。今ではPocochaマンスリー上位の常連です。</p>
      </article>
      <article class="voice-card">
        <div class="voice-quote">"還元率100%は伊達じゃない。<br>給料明細が透明で安心。"</div>
        <div class="voice-meta">
          <div class="voice-avatar" aria-hidden="true">M.A</div>
          <div><strong>M.A さん</strong><span>Pococha / 在籍2年</span></div>
        </div>
        <p class="voice-body">前は別の事務所でしたが、計算根拠が不透明で。Live-Laboはダイヤがそのまま入ってきます。手数料の引き方も明朗で乗り換えて正解でした。</p>
      </article>
      <article class="voice-card">
        <div class="voice-quote">"住所提供と確定申告サポートが<br>地方民にはありがたすぎる。"</div>
        <div class="voice-meta">
          <div class="voice-avatar" aria-hidden="true">Y.K</div>
          <div><strong>Y.K さん</strong><span>17LIVE / 在籍4年</span></div>
        </div>
        <p class="voice-body">地方在住なので、ファンレターを自宅に届けたくなくて。事務所住所が使えるのは本当に助かります。確定申告も提携税理士さんが半額で見てくれます。</p>
      </article>
    </div>
  </div>
</section>

<!-- ========== Flow ========== -->
<section class="flow" id="flow">
  <div class="section-inner">
    <span class="section-eyebrow">How to Join</span>
    <h2 class="section-title">最短<span class="accent">3分</span>で応募完了</h2>
    <p class="section-lead">LINEから気軽に。難しい書類も初期費用も一切ありません。</p>
    <div class="flow-grid">
      <div class="flow-step">
        <div class="flow-step-num">01</div>
        <h3>LINEで応募</h3>
        <p>下のボタンから公式LINEへ。簡単な質問にお答えいただくだけ。</p>
      </div>
      <div class="flow-step">
        <div class="flow-step-num">02</div>
        <h3>担当から連絡</h3>
        <p>24時間以内に専任担当者からご返信。気になる点は何でもご相談ください。</p>
      </div>
      <div class="flow-step">
        <div class="flow-step-num">03</div>
        <h3>オンライン面談</h3>
        <p>あなたの目標・ライフスタイルに合った配信プランをご提案します。</p>
      </div>
      <div class="flow-step">
        <div class="flow-step-num">04</div>
        <h3>契約・デビュー</h3>
        <p>契約完了後、初配信のセッティングまで全力でサポートします。</p>
      </div>
    </div>
  </div>
</section>

<!-- ========== FAQ ========== -->
<section class="faq" id="faq">
  <div class="section-inner">
    <span class="section-eyebrow">FAQ</span>
    <h2 class="section-title">よくある<span class="accent">ご質問</span></h2>
    <div class="faq-list">
      <details class="faq-item">
        <summary>未経験ですが大丈夫ですか？</summary>
        <div class="faq-body">もちろんです。Live-Laboの所属ライバーの多くは未経験スタート。初配信前から専属マネージャーが徹底サポートし、平均1〜3ヶ月でS帯ランクへ到達した実績があります。</div>
      </details>
      <details class="faq-item">
        <summary>契約料・初期費用はかかりますか？</summary>
        <div class="faq-body">一切かかりません。登録・契約・サポート、すべて無料です。配信に必要な機材レンタルも、キャンペーン適用で無料でご用意しています。</div>
      </details>
      <details class="faq-item">
        <summary>年齢制限はありますか？</summary>
        <div class="faq-body">18歳以上の方であればご応募いただけます。未成年の方は保護者の同意が必要となります。</div>
      </details>
      <details class="faq-item">
        <summary>地方在住でも所属できますか？</summary>
        <div class="faq-body">はい、全国どこからでもOKです。打ち合わせ・面談はオンラインで完結し、機材も郵送でお届けします。住所提供サービスも全国対応です。</div>
      </details>
      <details class="faq-item">
        <summary>顔出しは必須ですか？</summary>
        <div class="faq-body">必須ではありません。声配信・Vライバーなど、顔を出さないスタイルでも活躍できる戦略をご提案します。</div>
      </details>
      <details class="faq-item">
        <summary>会社員・主婦・学生でも両立できますか？</summary>
        <div class="faq-body">可能です。配信ノルマは強制せず、あなたのライフスタイルに合わせた時間設計をサポートします。副業禁止のお仕事の方はご応募前にご確認ください。</div>
      </details>
      <details class="faq-item">
        <summary>他事務所と並行して所属できますか？</summary>
        <div class="faq-body">原則、他事務所との重複契約はお断りしています。他事務所をご解約後にご連絡ください。両立をご希望の場合はLINEにてご相談ください。</div>
      </details>
    </div>
  </div>
</section>

<!-- ========== Inline Quick Form ========== -->
<section class="quick-form" id="form">
  <div class="section-inner">
    <div class="qf-wrap">
      <div class="qf-side">
        <span class="section-eyebrow">Quick Form</span>
        <h2 class="section-title">LINEが苦手な方は<br><span class="accent">フォームから</span></h2>
        <p class="section-lead">30秒で完了。担当者から24時間以内にご連絡いたします。</p>
        <ul class="qf-bullets">
          <li>個人情報は厳重に管理（プライバシーポリシー準拠）</li>
          <li>営業電話・しつこい勧誘は一切なし</li>
          <li>無料相談・キャンセル自由</li>
        </ul>
      </div>
      <form class="qf-form" action="https://formsubmit.co/arigatou@live-labo.jp" method="POST">
        <!-- 送信設定（FormSubmit）: 件名・整形・スパム対策。送信先=arigatou@live-labo.jp -->
        <input type="hidden" name="_subject" value="【Live-Labo】無料相談の新規応募">
        <input type="hidden" name="_template" value="table">
        <input type="hidden" name="_captcha" value="false">
        <input type="hidden" name="_autoresponse" value="お問い合わせありがとうございます。Live-Labo担当者より24時間以内にご連絡いたします。">
        <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div class="qf-row">
          <label>お名前（ニックネーム可）<span class="req">必須</span></label>
          <input type="text" name="お名前" required placeholder="例：山田 花子">
        </div>
        <div class="qf-row">
          <label>連絡先（メール or 電話）<span class="req">必須</span></label>
          <input type="text" name="連絡先" required placeholder="例：hanako@example.com">
        </div>
        <div class="qf-row">
          <label>年齢</label>
          <select name="年齢">
            <option>18-22歳</option>
            <option>23-29歳</option>
            <option>30-39歳</option>
            <option>40歳以上</option>
          </select>
        </div>
        <div class="qf-row">
          <label>配信経験</label>
          <div class="qf-radio">
            <label><input type="radio" name="配信経験" value="未経験" checked>未経験</label>
            <label><input type="radio" name="配信経験" value="少しある">少しある</label>
            <label><input type="radio" name="配信経験" value="経験者">経験者</label>
          </div>
        </div>
        <button type="submit" class="btn btn-secondary btn-arrow" style="width:100%;background:var(--black);color:#fff;margin-top:8px">無料相談を申し込む</button>
        <p class="qf-note">送信いただいた情報は<a href="https://live-labo.jp/privacy-policy/">プライバシーポリシー</a>に従い厳重に管理いたします。</p>
      </form>
    </div>
  </div>
</section>

<!-- ========== Final CTA ========== -->
<section class="cta-final" id="contact">
  <div class="section-inner">
    <h2>"配信したい"を、<br>今日、はじめてみませんか。</h2>
    <p>LINEから3分。質問だけでも大歓迎です。</p>
    <div class="cta-final-buttons">
      <a href="https://lin.ee/vMcAZIJ" class="btn btn-primary btn-large btn-arrow">LINEで無料相談</a>
      <a href="#form" class="btn btn-ghost btn-large btn-arrow">フォームから応募</a>
    </div>
    <p class="cta-final-note">© 株式会社Live-Labo｜東京都渋谷区恵比寿南1-1-1 Humax Ebisu 8F</p>
  </div>
</section>

<!-- ========== Footer ========== -->
<footer class="site-footer">
  <div class="footer-inner">
    <div>© 2026 Live-Labo Inc. All rights reserved.</div>
    <div class="footer-right">
      <div class="footer-links">
        <a href="https://live-labo.jp/">トップへ戻る</a>
        <a href="https://live-labo.jp/about/">運営会社</a>
        <a href="https://live-labo.jp/privacy-policy/">プライバシーポリシー</a>
        <a href="https://live-labo.jp/contact/">お問い合わせ</a>
      </div>
      <div class="footer-social">
        <a href="https://www.instagram.com/livelabo__official" target="_blank" rel="noopener noreferrer" aria-label="Live-Labo 公式Instagram" title="公式Instagram">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="2.5" width="19" height="19" rx="5.2"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.6" cy="6.4" r="1.1" fill="currentColor" stroke="none"/></svg>
        </a>
        <a href="https://x.com/livelabo_oa" target="_blank" rel="noopener noreferrer" aria-label="Live-Labo 公式X（旧Twitter）" title="公式X">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
        </a>
      </div>
    </div>
  </div>
</footer>

<!-- ========== Always-on bottom LINE CTA bar (ONECARAT signature) ========== -->
<a href="https://lin.ee/vMcAZIJ" class="line-bar" aria-label="LINEで無料相談">
  LINEで無料相談する
  <span class="line-bar-tap">TAP</span>
</a>

<script>
  // Fade-in on scroll
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  },{threshold:.15});
  document.querySelectorAll('.fade-in').forEach(el=>io.observe(el));

  // スマホ: ハンバーガーメニューの開閉
  const siteHeader = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  if(siteHeader && navToggle){
    navToggle.addEventListener('click', ()=>{
      const open = siteHeader.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.querySelectorAll('#mobileMenu a').forEach(a=>{
      a.addEventListener('click', ()=>{
        siteHeader.classList.remove('open');
        navToggle.setAttribute('aria-expanded','false');
      });
    });
  }

  // ライバー写真帯: 2段目を生成（1段目を複製して逆方向にスクロール）
  const marquee = document.querySelector('.liver-marquee');
  const firstVp = marquee ? marquee.querySelector('.marquee-viewport') : null;
  if(firstVp){
    const secondVp = firstVp.cloneNode(true);
    const track = secondVp.querySelector('.marquee-track');
    track.classList.add('marquee-track--rev');
    Array.from(track.children).reverse().forEach(el=>track.appendChild(el)); // 上下で並び順を変える
    firstVp.insertAdjacentElement('afterend', secondVp);
  }
</script>

  <?php wp_footer(); ?>
</body>
</html>
