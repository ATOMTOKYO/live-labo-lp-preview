<?php
/*
 * livelabonew-child functions.
 * 親テーマ(livelabonew)は get_template_directory_uri() でCSS/JSを読み込むため、
 * 子テーマ有効化時も親の functions.php が実行され他ページのデザインは維持される。
 * よってここでの追加処理は不要（front-page.php のみ上書き）。
 */
