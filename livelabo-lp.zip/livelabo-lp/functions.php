<?php
/* livelabo-lp: 自己完結型テーマ（front-page.php / index.php にLP全体をインライン）。追加処理は不要。 */
add_theme_support('title-tag');
add_theme_support('post-thumbnails');
